#include "ModeCustom.h"
#include "Utility.h"


CModeCustom::CModeCustom(void)
{
	mode_track = 1;
}


CModeCustom::~CModeCustom(void)
{
}


void CModeCustom::Initialize(void)
{
	int i;
	vec3 aLocation, bLocation;
	CCamera camBall;

	switch (Main->ProgramMode)
	{
	case 10:
		Main->move_camera_direction = false;
		if (BallCursor == 0) BallCursor = 1;
		PitchFormCursor = 1;
		EditCursor = 1;
		break;

	case 11:
		break;

	case 12:
		CustomVelocity = BaseBall[BallCursor].Track.Origin.velocity_length() * 3600.0f / 1000.0f;
		CustomiVelocity = BaseBall[BallCursor].CustomiVelocity;
		CustomSpin = BaseBall[BallCursor].Track.Origin.spin * 60.0f / 2.0 / PI;
		CustomiSpin = BaseBall[BallCursor].CustomiSpin;

		aLocation = vec3(BaseBall[BallCursor].Track.Origin.location.x, BaseBall[BallCursor].Track.Origin.location.y, BaseBall[BallCursor].Track.Origin.location.z);
		bLocation = vec3(0, 0, (Main->StrikeZoneSize.x + Main->StrikeZoneSize.y) / 2.0f);

		aLocation -= bLocation;
		aLocation.normalize();
		aLocation = aLocation * 2.0f + bLocation;

		Main->Initialize_Camera(10);
		camBall.eye = aLocation;
		camBall.at = bLocation;
		camBall.up = vec3(0, 0, 1);
		camBall.fovy *= 0.1f;
		camBall.view_matrix = mat4::look_at(camBall.eye, camBall.at, camBall.up);
		Main->camlist[0] = camBall;
		Main->cam = camBall;

		Main->move_camera_direction = true;
		break;

	case 13:
		DetailCursor = 1;
		break;

	case 14:
		if (EditCursor == 5) BaseBall[BallCursor].Track.Origin.spin_angle = 0;
		break;

	case 15: // Input Detail
		switch (EditCursor)
		{
		case 1: // Name
			InputTitle = "Name";
			sprintf(InputDetail, "%s", BaseBall[BallCursor].Track.Property.name);
			InputType = 1;
			break;

		case 2: // Location
			switch (DetailCursor)
			{
			case 1:
				InputTitle = "Location(x)";
				sprintf(InputDetail, "%g", BaseBall[BallCursor].Track.Origin.location.x);
				InputType = 3;
				break;

			case 2:
				InputTitle = "Location(y)";
				sprintf(InputDetail, "%g", BaseBall[BallCursor].Track.Origin.location.y);
				InputType = 3;
				break;

			case 3:
				InputTitle = "Location(z)";
				sprintf(InputDetail, "%g", BaseBall[BallCursor].Track.Origin.location.z);
				InputType = 3;
				break;

			}
			break;

		case 3: // Velocity
			switch (DetailCursor)
			{
			case 1:
				InputTitle = "Velocity";
				sprintf(InputDetail, "%g", CustomVelocity);
				InputType = 3;
				break;

			}
			break;

		case 4: // Spin
			switch (DetailCursor)
			{
			case 1:
				InputTitle = "Spin";
				sprintf(InputDetail, "%g", CustomSpin);
				InputType = 3;
				break;

			}
			break;

		case 5: // Initial Angle
			switch (DetailCursor)
			{
			case 1:
				InputTitle = "Angle(x)";
				sprintf(InputDetail, "%g", BaseBall[BallCursor].Track.Origin.angle.x);
				InputType = 3;
				break;

			case 2:
				InputTitle = "Angle(y)";
				sprintf(InputDetail, "%g", BaseBall[BallCursor].Track.Origin.angle.y);
				InputType = 3;
				break;

			case 3:
				InputTitle = "Angle(z)";
				sprintf(InputDetail, "%g", BaseBall[BallCursor].Track.Origin.angle.z);
				InputType = 3;
				break;

			}
			break;

		case 6: // Proficiency
			InputTitle = "Proficiency";
			sprintf(InputDetail, "%g", Proficiency[BallCursor]);
			InputType = 3;
			break;

		case 7: // Frequency
			InputTitle = "Frequency";
			sprintf(InputDetail, "%d", Frequency[BallCursor]);
			InputType = 2;
			break;

		}
		break;

	case 16: // Pitch Count
		sprintf(InputDetail, "%d", PitchCount);
		break;

	case 17: // Open File
		PitcherList = CFileList("..\\bin\\pitcher\\", "pitcher");
		PitcherList.GetList();

		DetailCursor = 0;
		break;

	case 18: // Save File
		break;

	case 19: // Simulation Start
		Main->Initialize_Camera(10);
		Main->nowcam = 1;
		Main->move_camera_direction = true;
		for (i = 1; i <= nBaseBall; i++)
		{
			if (BaseBall[i].balltype > 0) BaseBall[i].balltype = 0;
			BaseBall[i].idxTrack = 0;
			BaseBall[i].BallZone_visible = false;
		}

		Main->ClearSchedule();
		TotalBallType = 0;
		break;
	}

	//BaseBall.pitchformtype = 0;
	//BaseBall_com.pitchformtype = 0;

//	engine->play2D(sound_gamestart);
}


void CModeCustom::Render(void)
{
	int i, len, tmpCursor;
	float dpi_scale, tmp, size;
	float a = abs(sin(Main->t * 2.5f));
	char szText[1024];
	uint uloc;
	vec3 Color;
	string szTextBall;
	vec3 ColorBall[8] = { vec3(1.0f, 1.0f, 1.0f), vec3(1.0f, 0.0f, 0.0f), vec3(1.0f, 0.5f, 0.0f), vec3(1.0f, 1.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f), vec3(0.0f, 0.5f, 1.0f), vec3(0.0f, 0.0f, 1.0f), vec3(0.5f, 0.0f, 0.5f) };

	dpi_scale = cg_get_dpi_scale();

	switch (Main->ProgramMode)
	{
	case 10: // Custom mode - Menu
		Main->Render_Text("Prism Pitch Perfection", 100, 100, 1.0f, vec4(0.5f, 0.8f, 0.2f, a), dpi_scale);

		// �� ������
		tmpCursor = (BallCursor - 1) / 4;
		for (i = tmpCursor * 4 + 1; i <= (tmpCursor + 1) * 4 && i <= nBaseBall; i++)
		{
			if (BaseBall[i].Track.Origin.velocity_length() == 0)
			{
				szTextBall = "No Ball Information";
			}
			else
			{
				szTextBall = BaseBall[i].Track.Property.name;
				if (szTextBall == "") szTextBall = "Empty Name";
				szTextBall += " ( ";
				szTextBall += to_string((int)(BaseBall[i].Track.Origin.velocity_length() * 3600.0f / 1000.0f + 0.5)); // m/s -> km/h
				szTextBall += "km/h, ";
				szTextBall += to_string((int)(BaseBall[i].Track.Origin.spin * 60.0f / 2.0 / PI + 0.5)); // rad/s to spin/m
				szTextBall += "rpm )";
			}

			if (BallCursor == i) tmp = 0.8f, size = 0.6f;
			else tmp = 0.5f, size = 0.5f;
			Main->Render_Text(szTextBall, 70, 180 + (i + 3) % 4 * 50, size, vec4(ColorBall[i], tmp), dpi_scale);
		}
		sprintf(szText, "%d / %d Balls", BallCursor, nBaseBall);
		Main->Render_Text(szText, 130, Main->window_size.y - 50, 0.3f, vec4(0.9f, 0.9f, 0.8f, 1.0f), 1.0f);

		glUseProgram(Main->Program);

		break;

	case 11: // Create New Pitch Type
		Color = vec3(200.0f / 255.0f, 200.0f / 255.0f, 200.0f / 255.0f);
		Main->Render_Text("Select Pitch Type", 100, 100, 1.0f, vec4(180.0f / 255.0f, 180.0f / 255.0f, 100.0f / 255.0f, 1.0f), dpi_scale);

		for (i = 1; i <= nPitchFormInformation - 1; i++)
		{
			tmp = 1.0f, size = 0.6f;
			if (i != PitchFormCursor) tmp = 0.6f, size = 0.5f;

			Main->Render_Text(PitchFormInformation[i].first, 100, 120 + i * 30, size, vec4(Color, tmp), dpi_scale);
		}
		glUseProgram(Main->Program);

		break;

	case 13: // View Ball Information
		Main->Render_BaseBall(BaseBall[BallCursor], true);
		Main->Render_Stadium();
		if (mode_track == 1)
		{
			Main->Render_BallMovement(BaseBall[BallCursor]);
		}
		Main->Render_BallZone(BaseBall[BallCursor], 2);

		Render_BallInformation(BaseBall[BallCursor]);

		break;

	case 14: // Edit Ball Information
		Main->Render_BaseBall(BaseBall[BallCursor], true);
		Main->Render_Stadium();
		if (EditCursor == 4) Main->Render_SpinAxis(BaseBall[BallCursor], CustomiSpin);
		if (mode_track == 1)
		{
			Main->Render_BallMovement(BaseBall[BallCursor]);
		}
		Main->Render_BallZone(BaseBall[BallCursor], 2);

		Render_BallInformation(BaseBall[BallCursor], EditCursor);

		break;

	case 15: // Input Detail
		Main->Render_BaseBall(BaseBall[BallCursor], true);
		Main->Render_Stadium();
		if (EditCursor == 4) Main->Render_SpinAxis(BaseBall[BallCursor], CustomiSpin);
		if (mode_track == 1)
		{
			Main->Render_BallMovement(BaseBall[BallCursor]);
		}
		Main->Render_BallZone(BaseBall[BallCursor], 2);

		Render_InputDetail();

		break;

	case 16: // Pitch Count
		Main->Render_Text("Pitch Count", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "  %s_", InputDetail);
		Main->Render_Text(szText, 55, 15 + 2.5 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 17: // Open File
		Main->Render_Text("Load Pitcher", 100, 50, 0.8f, vec4(0.5f, 0.8f, 0.2f, 1.0f), 1.0f);
		len = PitcherList.FileList.size();
		if (len == 0)
		{
			MessageBox(NULL, L"���� ���� ������ �������� �ʽ��ϴ�!", L"Prism Pitch Perfection", 0);
			Main->ProgramMode = 0;
		}
		// 10������ ǥ��
		tmpCursor = DetailCursor / 10;
		for (i = tmpCursor * 10; i < (tmpCursor + 1) * 10 && i < len; i++)
		{
			if (i == DetailCursor) tmp = 1.0f, size = 0.6f;
			else tmp = 0.4f, size = 0.55f;
			Main->Render_Text(PitcherList.FileList[i].c_str(), 100, 100 + 30 * (i % 10), size, vec4(0.5f, 0.7f, 0.7f, tmp), 1.0f);
		}
		sprintf(szText, "%d / %d Pitcher", DetailCursor + 1, PitcherList.FileList.size());
		Main->Render_Text(szText, 130, Main->window_size.y - 50, 0.3f, vec4(0.9f, 0.9f, 0.8f, 1.0f), 1.0f);
		glUseProgram(Main->Program);

		break;

	case 18: // Save File
		Main->Render_Text("Save Pitcher", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "  %s_", szFileName);
		Main->Render_Text(szText, 55, 15 + 2.5 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 19: // Simulation Start
		Main->Render_Stadium(Main->EmptySchedule());

		uloc = glGetUniformLocation(Main->Program, "b_modeball");
		for (i = 1; i <= nBaseBall; i++)
		{
			if (BaseBall[i].Track.Origin.velocity_length() != 0 && BaseBall[i].balltype >= 0)
			{
				glUniform1i(uloc, i);

				// BaseBall ���
				if (BaseBall[i].balltype == 0 || BaseBall[i].balltype == 1) Main->Render_BaseBall(BaseBall[i]);

				// ��Ʈ����ũ���� ǥ�õ� �� ���    
				if (BaseBall[i].BallZone_visible)
				{
					Main->Render_BallZone(BaseBall[i], 2);
				}

				if (mode_track == 1)
				{
					Main->Render_BallMovement(BaseBall[i]);
				}
			}
		}
		glUniform1i(uloc, 0);

		break;
	}
}


void CModeCustom::Update(void)
{
	int Result, i, flag;

	while (1)
	{
		Result = 0;

		switch (Main->ProgramMode)
		{
		case 10: // Custom mode - Menu
			break;

		case 11: // Mode Select Pitch Type
			break;

		case 12:
			Main->ProgramMode = 13;
			break;

		case 13: case 14: case 15: // Input Speed and Spin
			if (!((Main->ProgramMode == 14 || Main->ProgramMode == 15) && EditCursor == 5) && BaseBall[BallCursor].nowframe + 1.0f / Main->framefps <= Main->t)
			{
				double spin = BaseBall[BallCursor].Track.Origin.spin, pspin = Main->max_previewspin * 2 * PI / 60.0f;
				if (spin > pspin) spin = pspin;

				while (BaseBall[BallCursor].nowframe + 1.0f / Main->framefps <= Main->t)
				{
					BaseBall[BallCursor].nowframe += 1.0f / Main->framefps;
					BaseBall[BallCursor].Track.Origin.spin_angle += spin / Main->framefps;
					if (BaseBall[BallCursor].Track.Origin.spin_angle >= 2 * PI) BaseBall[BallCursor].Track.Origin.spin_angle -= 2 * PI; if (BaseBall[BallCursor].Track.Origin.spin_angle <= -2 * PI) BaseBall[BallCursor].Track.Origin.spin_angle += 2 * PI;
					BaseBall[BallCursor].BallZone.spin_angle += spin / Main->framefps;
					if (BaseBall[BallCursor].BallZone.spin_angle >= 2 * PI) BaseBall[BallCursor].BallZone.spin_angle -= 2 * PI; if (BaseBall[BallCursor].BallZone.spin_angle <= -2 * PI) BaseBall[BallCursor].BallZone.spin_angle += 2 * PI;
				}
			}

			break;

		case 16: // Pitch Count
			break;

		case 17: // Open File
			break;

		case 18: // Save File
			break;

		case 19: // Simulation Start
			Result = Main->GetSchedule();
			switch (Result)
			{
			case 1:
				flag = 0;
				for (i = 1; i <= nBaseBall; i++)
				{
					Main->Update_Ball(BaseBall[i]);
					if (BaseBall[i].balltype == 1) flag = 1;
				}

				if (flag == 0) TotalBallType = 2;

				break;
			}

		}

		if (Result == 0) break;
	}
}


void CModeCustom::Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	int i, tmp = 1;

	if (mods & GLFW_MOD_SHIFT) tmp *= 10;

	switch (Main->ProgramMode)
	{
	case 10: // Custom mode - Menu
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE || key == GLFW_KEY_Q) Main->ProgramMode = 0; // Main
			else if (key == GLFW_KEY_UP)
			{
				BallCursor = (BallCursor + 5) % 7 + 1;
			}
			else if (key == GLFW_KEY_DOWN)
			{
				BallCursor = BallCursor % 7 + 1;
			}
			else if (key == GLFW_KEY_ENTER) // ����
			{
				if (BaseBall[BallCursor].Track.Origin.velocity_length() != 0) Main->ProgramMode = 12;
			}
			else if (key == GLFW_KEY_N) // ����
			{
				if (BaseBall[BallCursor].Track.Origin.velocity_length() == 0) Main->ProgramMode = 11;
			}
			else if (key == GLFW_KEY_DELETE) // Empty Ball�� �ʱ�ȭ
			{
				BaseBall[BallCursor].ClearBall();
			}
			else if (key == GLFW_KEY_SPACE) // �ùķ����� ����
			{
				Main->ProgramMode = 19;
			}
			else if (key == GLFW_KEY_P)
			{
				Main->ProgramMode = 16;
			}
			else if (mods & GLFW_MOD_CONTROL && key == GLFW_KEY_O)
			{
				Main->ProgramMode = 17;
			}
			else if (mods & GLFW_MOD_CONTROL && key == GLFW_KEY_S)
			{
				Main->ProgramMode = 18;
			}
		}
		break;

	case 11: // Mode Select Pitch Type
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 10;
			}
			else if (key == GLFW_KEY_ENTER)
			{
				// Create new ball
				BaseBall[BallCursor].CustomiVelocity = ivec2(Main->min_velocity_angle * 3 / 2, Main->min_velocity_angle * 1 / 2);
				BaseBall[BallCursor].CustomiSpin = ivec2(0, Main->min_spin_angle * 3 / 2);

				BaseBall[BallCursor].Track.Origin.location = PitchFormInformation[PitchFormCursor].second;
				BaseBall[BallCursor].Track.Origin.angle = dvec3(0, 0, 0);
				BaseBall[BallCursor].Track.Origin.spin_euler = dvec2(PI * BaseBall[BallCursor].CustomiSpin.x / Main->min_spin_angle, PI * BaseBall[BallCursor].CustomiSpin.y / Main->min_spin_angle);
				BaseBall[BallCursor].Track.Origin.spin_angle = 0;
				BaseBall[BallCursor].Track.Origin.velocity = dvec3(0, -100 * 1000.0f / 3600.0f, 0); // 100km
				BaseBall[BallCursor].Track.Origin.spin = 100 / 60.0f * 2.0 * PI; // 100rpm
				BaseBall[BallCursor].Track.Property.frequency = 1;
				BaseBall[BallCursor].Track.Property.proficiency = 0.7f;

				BaseBall[BallCursor].ThrowBall(1.0f / Main->ball_framefps, 0);

				Main->ProgramMode = 10;
			}
			else if (key == GLFW_KEY_UP)
			{
				if (PitchFormCursor > 1) PitchFormCursor--;
			}
			else if (key == GLFW_KEY_DOWN)
			{
				if (PitchFormCursor < nPitchFormInformation - 1) PitchFormCursor++;
			}
		}
		break;

	case 13: // View Ball Information
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 10;
			}
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_PAGE_UP) Main->Camera_Prev();
			else if (key == GLFW_KEY_PAGE_DOWN) Main->Camera_Next();
			else if (key == GLFW_KEY_T) mode_track = (mode_track + 1) % 2;
			else if (key == GLFW_KEY_ENTER)
			{
				if (EditCursor == 1 || EditCursor == 6 || EditCursor == 7) Main->ProgramMode = 15;
				else if (EditCursor == 8) break;
				else Main->ProgramMode = 14;
				memset(InputDetail, 0, sizeof(InputDetail));
			}
			else if (key == GLFW_KEY_UP)
			{
				if (EditCursor > 1) EditCursor--;
			}
			else if (key == GLFW_KEY_DOWN)
			{
				if (EditCursor < 8) EditCursor++;
			}
			else if (key == GLFW_KEY_SPACE && EditCursor == 8)
			{
				if (BaseBall[BallCursor].balltype >= 0) BaseBall[BallCursor].balltype = -1;
				else BaseBall[BallCursor].balltype = 0;
			}
		}
		break;

	case 14: // Edit Ball Informations
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE) Main->ProgramMode = 13;
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_PAGE_UP) Main->Camera_Prev();
			else if (key == GLFW_KEY_PAGE_DOWN) Main->Camera_Next();
			else if (key == GLFW_KEY_T) mode_track = (mode_track + 1) % 2;
			else if (key == GLFW_KEY_ENTER) memset(InputDetail, 0, sizeof(InputDetail)), Main->ProgramMode = 15;
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				printf("Location(%g %g %g), ", BaseBall[BallCursor].Track.Origin.location.x, BaseBall[BallCursor].Track.Origin.location.y, BaseBall[BallCursor].Track.Origin.location.z);
				printf("SpinEuler(%g %g)\n", BaseBall[BallCursor].Track.Origin.spin_euler.x, BaseBall[BallCursor].Track.Origin.spin_euler.y);
				printf("CustomVelocity(%d %d), ", CustomiVelocity.x, CustomiVelocity.y);
				printf("CustomiSpin(%d %d)\n", CustomiSpin.x, CustomiSpin.y);
				/*printf("BaseBall Speed (%g %g %g), ", pBaseBall->Track.Origin.velocity.x, pBaseBall->Track.Origin.velocity.y, pBaseBall->Track.Origin.velocity.z);
				printf("Location(%g %g %g)\n", pBaseBall->Track.Origin.location.x, pBaseBall->Track.Origin.location.y, pBaseBall->Track.Origin.location.z);
				printf("CustomSpin(%g %g), ", PI * CustomiSpin.x / min_spin_angle, PI * CustomiSpin.y / min_spin_angle);
				printf("Spin(%g %g %g), ", pBaseBall->Track.Origin.spin.x, pBaseBall->Track.Origin.spin.y, pBaseBall->Track.Origin.spin.z);
				printf("Angle(%.3f %.3f %.3f)\n", pBaseBall->Track.Origin.angle.x, pBaseBall->Track.Origin.angle.y, pBaseBall->Track.Origin.angle.z);*/
				printf("Camera.eye(%.3f %.3f %.3f)\n", Main->cam.eye.x, Main->cam.eye.y, Main->cam.eye.z);
				printf("Camera.at(%.3f %.3f %.3f)\n", Main->cam.at.x, Main->cam.at.y, Main->cam.at.z);
				printf("Camera.up(%.3f %.3f %.3f)\n", Main->cam.up.x, Main->cam.up.y, Main->cam.up.z);
			}
			else
			{
				switch (EditCursor)
				{
				case 1: // Name
					break;

				case 2: // Location
					if (key == GLFW_KEY_UP)
					{
						if (DetailCursor > 1) DetailCursor--;
					}
					else if (key == GLFW_KEY_DOWN)
					{
						if (DetailCursor < 3) DetailCursor++;
					}

					break;

				case 3: // Velocity
					if (key == GLFW_KEY_UP)
					{
						if (DetailCursor > 1) DetailCursor--;
					}
					else if (key == GLFW_KEY_DOWN)
					{
						if (DetailCursor < 2) DetailCursor++;
					}
					break;

				case 4: // Spin
					if (key == GLFW_KEY_UP)
					{
						if (DetailCursor > 1) DetailCursor--;
					}
					else if (key == GLFW_KEY_DOWN)
					{
						if (DetailCursor < 2) DetailCursor++;
					}
					break;

				case 5: // Initial Angle
					if (key == GLFW_KEY_UP)
					{
						if (DetailCursor > 1) DetailCursor--;
					}
					else if (key == GLFW_KEY_DOWN)
					{
						if (DetailCursor < 3) DetailCursor++;
					}
					break;

				case 6: // Proficiency
					break;

				case 7: // Frequency
					break;

				}
			}
		}
		break;

	case 15: // Input Detail
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				if (EditCursor == 1 || EditCursor == 6 || EditCursor == 7) Main->ProgramMode = 13;
				else Main->ProgramMode = 14;
			}
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_PAGE_UP) Main->Camera_Prev();
			else if (key == GLFW_KEY_PAGE_DOWN) Main->Camera_Next();
			else if (key == GLFW_KEY_ENTER)
			{
				switch (EditCursor)
				{
				case 1: // Name
					Main->ProgramMode = 13;
					strcpy(BaseBall[BallCursor].Track.Property.name, InputDetail);
					break;

				case 2: // Location
					Main->ProgramMode = 14;
					if (DetailCursor == 1) BaseBall[BallCursor].Track.Origin.location.x = atof(InputDetail);
					else if (DetailCursor == 2) BaseBall[BallCursor].Track.Origin.location.y = atof(InputDetail);
					else if (DetailCursor == 3) BaseBall[BallCursor].Track.Origin.location.z = atof(InputDetail);
					break;

				case 3: // Velocity
					Main->ProgramMode = 14;
					if (DetailCursor == 1) CustomVelocity = atof(InputDetail);
					break;

				case 4: // Spin
					Main->ProgramMode = 14;
					if (DetailCursor == 1) CustomSpin = atof(InputDetail);
					break;

				case 5: // Initial Angle
					Main->ProgramMode = 14;
					if (DetailCursor == 1) BaseBall[BallCursor].Track.Origin.angle.x = atof(InputDetail);
					else if (DetailCursor == 2) BaseBall[BallCursor].Track.Origin.angle.y = atof(InputDetail);
					else if (DetailCursor == 3) BaseBall[BallCursor].Track.Origin.angle.z = atof(InputDetail);
					break;

				case 6: // Proficiency
					Main->ProgramMode = 13;
					Proficiency[BallCursor] = atof(InputDetail);
					break;

				case 7: // Frequency
					Main->ProgramMode = 13;
					Frequency[BallCursor] = atoi(InputDetail);
					break;

				}

				Update_Custom();
			}
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				printf("Location(%g %g %g), ", BaseBall[BallCursor].Track.Origin.location.x, BaseBall[BallCursor].Track.Origin.location.y, BaseBall[BallCursor].Track.Origin.location.z);
				printf("SpinEuler(%g %g)\n", BaseBall[BallCursor].Track.Origin.spin_euler.x, BaseBall[BallCursor].Track.Origin.spin_euler.y);
				printf("CustomVelocity(%d %d), ", CustomiVelocity.x, CustomiVelocity.y);
				printf("CustomiSpin(%d %d)\n", CustomiSpin.x, CustomiSpin.y);
				printf("Camera.eye(%.3f %.3f %.3f)\n", Main->cam.eye.x, Main->cam.eye.y, Main->cam.eye.z);
				printf("Camera.at(%.3f %.3f %.3f)\n", Main->cam.at.x, Main->cam.at.y, Main->cam.at.z);
				printf("Camera.up(%.3f %.3f %.3f)\n", Main->cam.up.x, Main->cam.up.y, Main->cam.up.z);
			}
			else if (EditCursor == 3 && DetailCursor == 2) // Velocity
			{
				if (key == GLFW_KEY_UP)
				{
					if (CustomiVelocity.y >= 0 + tmp)
					{
						CustomiVelocity.y -= tmp;
						Update_Custom();
					}
				}
				else if (key == GLFW_KEY_DOWN)
				{
					if (CustomiVelocity.y <= Main->min_velocity_angle * 2 - tmp)
					{
						CustomiVelocity.y += tmp;
						Update_Custom();
					}
				}
				else if (key == GLFW_KEY_LEFT)
				{
					if ((Main->cam.eye - Main->cam.at).y >= 0)
					{
						if (CustomiVelocity.x <= Main->min_velocity_angle * 2 - tmp)
						{
							CustomiVelocity.x += tmp;
							Update_Custom();
						}
					}
					else
					{
						if (CustomiVelocity.x >= 0 + tmp)
						{
							CustomiVelocity.x -= tmp;
							Update_Custom();
						}
					}
				}
				else if (key == GLFW_KEY_RIGHT)
				{
					if ((Main->cam.eye - Main->cam.at).y >= 0)
					{
						if (CustomiVelocity.x >= 0 + tmp)
						{
							CustomiVelocity.x -= tmp;
							Update_Custom();
						}
					}
					else
					{
						if (CustomiVelocity.x <= Main->min_velocity_angle * 2 - tmp)
						{
							CustomiVelocity.x += tmp;
							Update_Custom();
						}
					}
				}
			}
			else if (EditCursor == 4 && DetailCursor == 2) // Spin
			{
				if (key == GLFW_KEY_UP)
				{
					CustomiSpin.y = (CustomiSpin.y + tmp) % (Main->min_spin_angle * 2);
					Update_Custom();
				}
				else if (key == GLFW_KEY_DOWN)
				{
					CustomiSpin.y = (CustomiSpin.y - tmp + Main->min_spin_angle * 2) % (Main->min_spin_angle * 2);
					Update_Custom();
				}
				else if (key == GLFW_KEY_LEFT)
				{
					CustomiSpin.x = (CustomiSpin.x - tmp + Main->min_spin_angle) % Main->min_spin_angle;
					Update_Custom();
				}
				else if (key == GLFW_KEY_RIGHT)
				{
					CustomiSpin.x = (CustomiSpin.x + tmp) % Main->min_spin_angle;
					Update_Custom();
					break;
				}
			}
			else if (key == GLFW_KEY_BACKSPACE)
			{
				if (InputDetail[0] != 0) InputDetail[strlen(InputDetail) - 1] = 0;
			}
			else if (InputType == 1) // 1: String
			{
				if ('A' <= key && key <= 'Z')
				{
					bool Case = 1;
					if (mods & GLFW_MOD_CAPS_LOCK) Case = !Case;
					if (mods & GLFW_MOD_SHIFT) Case = !Case;
					InputDetail[strlen(InputDetail)] = key + Case * ('a' - 'A');
				}
				else if ((mods & GLFW_MOD_SHIFT) && key == '9') InputDetail[strlen(InputDetail)] = '(';
				else if ((mods & GLFW_MOD_SHIFT) && key == '0') InputDetail[strlen(InputDetail)] = ')';
				else if (key == ' ' || key == '.' || key == '-' || '0' <= key && key <= '9') InputDetail[strlen(InputDetail)] = key;
			}
			else if (InputType == 2) // 2: Natural Number
			{
				if (key == '-' || '0' <= key && key <= '9') InputDetail[strlen(InputDetail)] = key;
			}
			else if (InputType == 3) // 3: Real Number
			{
				if (key == '-' || key == '.' || '0' <= key && key <= '9') InputDetail[strlen(InputDetail)] = key;
			}
		}
		break;

	case 16: // Pitch Count
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE) Main->ProgramMode = 10;
			else if (key == GLFW_KEY_ENTER)
			{
				PitchCount = atoi(InputDetail);
				Main->ProgramMode = 10;
			}
			else if (key == GLFW_KEY_BACKSPACE)
			{
				if (InputDetail[0] != 0) InputDetail[strlen(InputDetail) - 1] = 0;
			}
			else if ('0' <= key && key <= '9') InputDetail[strlen(InputDetail)] = key;
		}
		break;

	case 17: // Open File
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE) Main->ProgramMode = 10;
			else if (key == GLFW_KEY_UP)
			{
				DetailCursor = (DetailCursor - 1 + PitcherList.FileList.size()) % PitcherList.FileList.size();
			}
			else if (key == GLFW_KEY_DOWN)
			{
				DetailCursor = (DetailCursor + 1) % PitcherList.FileList.size();
			}
			else if (key == GLFW_KEY_PAGE_UP)
			{
				DetailCursor -= 10;
				if (DetailCursor - 1 < 0) DetailCursor = 0;
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				DetailCursor += 10;
				if (DetailCursor >= PitcherList.FileList.size()) DetailCursor = PitcherList.FileList.size() - 1;
			}
			else if (key == GLFW_KEY_ENTER)
			{
				OpenFile(PitcherList.FileList[DetailCursor]);
				Main->ProgramMode = 10;
			}
		}
		break;

	case 18: // Save File
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE) Main->ProgramMode = 10;
			else if (key == GLFW_KEY_UP)
			{
				if (DetailCursor - 1 >= 0) DetailCursor--;
			}
			else if (key == GLFW_KEY_DOWN)
			{
				if (DetailCursor + 1 < PitcherList.FileList.size()) DetailCursor++;
			}
			else if (key == GLFW_KEY_ENTER)
			{
				SaveFile(szFileName);
				Main->ProgramMode = 10;
			}
			else if (key == GLFW_KEY_BACKSPACE)
			{
				if (szFileName[0] != 0) szFileName[strlen(szFileName) - 1] = 0;
			}
			else if ('A' <= key && key <= 'Z')
			{
				bool Case = 1;
				if (mods & GLFW_MOD_CAPS_LOCK) Case = !Case;
				if (mods & GLFW_MOD_SHIFT) Case = !Case;
				szFileName[strlen(szFileName)] = key + Case * ('a' - 'A');
			}
			else if ((mods & GLFW_MOD_SHIFT) && key == '9') szFileName[strlen(szFileName)] = '(';
			else if ((mods & GLFW_MOD_SHIFT) && key == '0') szFileName[strlen(szFileName)] = ')';
			else if (key == ' ' || key == '.' || key == '-' || '0' <= key && key <= '9') szFileName[strlen(szFileName)] = key;
		}
		break;

	case 19: // Simulation Start
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE) Main->ProgramMode = 10;
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_PAGE_UP)
			{
				Main->Camera_Prev();
				if (Main->nowcam == 0) Main->Camera_Prev();
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				Main->Camera_Next();
				if (Main->nowcam == 0) Main->Camera_Next();
			}
			else if (key == GLFW_KEY_SPACE)
			{
				if (TotalBallType == 0) // ���� -> �� ������
				{
					int max = 0, maxindex = -1;

					for (i = 1; i <= nBaseBall; i++)
					{
						if (BaseBall[i].Track.Origin.velocity_length() == 0 || BaseBall[i].balltype < 0) continue;

						BaseBall[i].nowframe = Main->t;
						if (max < BaseBall[i].Track.Track.size())
						{
							max = BaseBall[i].Track.Track.size(), maxindex = i;
						}
					}

					if (maxindex != -1)
					{
						Main->SetSchedule(BaseBall[maxindex], 0, 1.0f);
						TotalBallType = 1;

						for (i = 1; i <= nBaseBall; i++)
						{
							if (BaseBall[i].Track.Origin.velocity_length() == 0 || BaseBall[i].balltype < 0) continue;

							BaseBall[i].balltype = 1;
						}

					}
				}
				else if (TotalBallType == 2) // ������
				{
					for (i = 1; i <= nBaseBall; i++)
					{
						if (BaseBall[i].Track.Origin.velocity_length() == 0 || BaseBall[i].balltype < 0) continue;

						BaseBall[i].idxTrack = 0;
						BaseBall[i].BallZone_visible = false;
						BaseBall[i].balltype = 0;
					}
					TotalBallType = 0;
				}
			}
			else if (key == GLFW_KEY_T)
			{
				mode_track = (mode_track + 1) % 2;
			}
		}
		break;
	}
}


void CModeCustom::Mouse(GLFWwindow* window, int button, int action, int mods)
{
}


void CModeCustom::Render_BallInformation(CBall& Ball, int Edit)
{
	float size;
	string szTextBall;
	char szText[1024];
	dvec3 Velocity;

	switch (Edit)
	{
	case 0: // ��ü ���
		// Name
		if (EditCursor == 1) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += "  ";
		szTextBall += Ball.Track.Property.name;
		if (strcmp(Ball.Track.Property.name, "") == 0) szTextBall += "Empty Name";

		Main->Render_Text(szTextBall, 20, 5 + 1 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Location
		if (EditCursor == 2) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += " Location";

		Main->Render_Text(szTextBall, 20, 5 + 2 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Velocity
		if (EditCursor == 3) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += " Velocity";

		Main->Render_Text(szTextBall, 20, 5 + 3 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "%.0fkm/h", CustomVelocity);
		Main->Render_Text(szText, 160, 5 + 3 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Spin
		if (EditCursor == 4) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += " Spin";

		Main->Render_Text(szTextBall, 20, 5 + 4 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "%.0frpm", CustomSpin);
		Main->Render_Text(szText, 160, 5 + 4 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Initial Angle
		if (EditCursor == 5) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += " Initial Angle";

		Main->Render_Text(szTextBall, 20, 5 + 5 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Proficiency
		if (EditCursor == 6) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += " Proficiency";

		Main->Render_Text(szTextBall, 20, 5 + 6 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "%.2f", Proficiency[BallCursor]);
		Main->Render_Text(szText, 160, 5 + 6 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Frequency
		if (EditCursor == 7) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";
		szTextBall += " Frequency";

		Main->Render_Text(szTextBall, 20, 5 + 7 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "%d", Frequency[BallCursor]);
		Main->Render_Text(szText, 160, 5 + 7 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		// Show / Hide
		if (EditCursor == 8) size = 0.35f, szTextBall = ">>";
		else size = 0.3f, szTextBall = "   ";

		if (Ball.balltype >= 0) strcpy(szText, " Show Ball");
		else strcpy(szText, " Hide Ball");
		szTextBall += szText;
		Main->Render_Text(szTextBall, 20, 5 + 8 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		break;

	case 1: // Name
		//sprintf(szText, "  %s_", BaseBall[BallCursor].Name);
		//Main->Render_Text(szText, 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 2: // Location
		Main->Render_Text("Location", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 1) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " x: %.2f", BaseBall[BallCursor].Track.Origin.location.x);
		Main->Render_Text(szTextBall + szText, 30, 15 + 2 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 2) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " y: %.2f", BaseBall[BallCursor].Track.Origin.location.y);
		Main->Render_Text(szTextBall + szText, 30, 15 + 3 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 3) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " z: %.2f", BaseBall[BallCursor].Track.Origin.location.z);
		Main->Render_Text(szTextBall + szText, 30, 15 + 4 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		break;

	case 3: // Velocity
		Main->Render_Text("Velocity", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 1) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, "%.0f km/h", CustomVelocity);
		Main->Render_Text(szTextBall + szText, 30, 15 + 2 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 2) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, "iV: %d, %d", CustomiVelocity.x, CustomiVelocity.y);
		Main->Render_Text(szTextBall + szText, 30, 15 + 3 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		Velocity = BaseBall[BallCursor].Track.Origin.velocity;
		sprintf(szText, " x: %.2f", Velocity.x * 3600.0f / 1000.0f);
		Main->Render_Text(szText, 30, 15 + 4 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, " y: %.2f", Velocity.y * 3600.0f / 1000.0f);
		Main->Render_Text(szText, 30, 15 + 5 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, " z: %.2f", Velocity.z * 3600.0f / 1000.0f);
		Main->Render_Text(szText, 30, 15 + 6 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 4: // Spin
		Main->Render_Text("Spin", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 1) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, "%.0f rpm", CustomSpin);
		Main->Render_Text(szTextBall + szText, 30, 15 + 2 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 2) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " spin_euler: %.2f, %.2f", BaseBall[BallCursor].Track.Origin.spin_euler.x, BaseBall[BallCursor].Track.Origin.spin_euler.y);
		Main->Render_Text(szTextBall + szText, 30, 15 + 3 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 5: // Initial Angle
		Main->Render_Text("Initial Angle", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 1) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " x: %.2f", BaseBall[BallCursor].Track.Origin.angle.x);
		Main->Render_Text(szTextBall + szText, 30, 15 + 2 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 2) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " y: %.2f", BaseBall[BallCursor].Track.Origin.angle.y);
		Main->Render_Text(szTextBall + szText, 30, 15 + 3 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));

		if (DetailCursor == 3) size = 0.35f, szTextBall = " ";
		else size = 0.3f, szTextBall = "";
		sprintf(szText, " z: %.2f", BaseBall[BallCursor].Track.Origin.angle.z);
		Main->Render_Text(szTextBall + szText, 30, 15 + 4 * 25, size, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 6: // Proficiency
		//Main->Render_Text("Proficiency", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		//sprintf(szText, "%g_", Proficiency[BallCursor]);
		//Main->Render_Text(szText, 30, 15 + 2 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	case 7: // Frequency
		//Main->Render_Text("Frequency", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		//sprintf(szText, "%d_", Frequency[BallCursor]);
		//Main->Render_Text(szText, 30, 15 + 2 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		break;

	}

	glUseProgram(Main->Program);

}


void CModeCustom::Render_InputDetail(void)
{
	float size;
	string szTextBall;
	char szText[1024];
	dvec3 Velocity;

	if (EditCursor == 3 && DetailCursor == 2)
	{
		Main->Render_Text("Velocity", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));

		sprintf(szText, "iV: %d, %d", CustomiVelocity.x, CustomiVelocity.y);
		Main->Render_Text(szText, 30, 15 + 2.5 * 25, 0.35f, vec4(0.95f, 0.95f, 0.95f, 1));

		Velocity = BaseBall[BallCursor].Track.Origin.velocity;
		sprintf(szText, " x: %.2f", Velocity.x * 3600.0f / 1000.0f);
		Main->Render_Text(szText, 30, 15 + 3.5 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, " y: %.2f", Velocity.y * 3600.0f / 1000.0f);
		Main->Render_Text(szText, 30, 15 + 4.5 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, " z: %.2f", Velocity.z * 3600.0f / 1000.0f);
		Main->Render_Text(szText, 30, 15 + 5.5 * 25, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1));
	}
	else if (EditCursor == 4 && DetailCursor == 2)
	{
		Main->Render_Text("Spin", 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));

		sprintf(szText, " spin_euler: %.2f, %.2f", BaseBall[BallCursor].Track.Origin.spin_euler.x, BaseBall[BallCursor].Track.Origin.spin_euler.y);
		Main->Render_Text(szText, 30, 15 + 2.5 * 25, 0.35f, vec4(0.95f, 0.95f, 0.95f, 1));

	}
	else
	{
		Main->Render_Text(InputTitle, 55, 15 + 1 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
		sprintf(szText, "  %s_", InputDetail);
		Main->Render_Text(szText, 55, 15 + 2.5 * 25, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1));
	}

	glUseProgram(Main->Program);

}


void CModeCustom::Update_Custom(void)
{
	BaseBall[BallCursor].CustomiVelocity = CustomiVelocity;
	BaseBall[BallCursor].CustomiSpin = CustomiSpin;

	//BaseBall[BallCursor].Track.Origin.angle = dvec3(0, PI * CustomiSpin.x, PI * CustomiSpin.y / Main->min_spin_angle);
	//BaseBall[BallCursor].Track.Origin.angle = dvec3(0, 0, 0);
	BaseBall[BallCursor].Track.Origin.spin_euler = dvec2(PI * CustomiSpin.x / Main->min_spin_angle, PI * CustomiSpin.y / Main->min_spin_angle);
	BaseBall[BallCursor].Track.Origin.spin_angle = 0;
	BaseBall[BallCursor].Track.Origin.velocity = EulerAngle(CustomiVelocity, Main->min_velocity_angle) * CustomVelocity * 1000.0f / 3600.0f;
	BaseBall[BallCursor].Track.Origin.spin = CustomSpin / 60.0f * 2.0 * PI;
	BaseBall[BallCursor].ThrowBall(1.0f / Main->ball_framefps, 0);
	BaseBall[BallCursor].nowframe = Main->t;

	//printf("%g %g %g\n", BaseBall[BallCursor].Track.Origin.angle.x, BaseBall[BallCursor].Track.Origin.angle.y, BaseBall[BallCursor].Track.Origin.angle.z);

}


void CModeCustom::OpenFile(string FileName)
{
	strcpy(szFileName, FileName.c_str());
	FileName = "..\\bin\\pitcher\\" + FileName + ".pitcher";
	CPitcher Pitcher;

	BaseBall[0].ClearBall();
	if (Pitcher.LoadPitcher(FileName.c_str(), BaseBall[0].Track.Property))
	{
		int i, len = Pitcher.PitchBall.size() - 1;

		if (len > 7) len = 7;
		for (i = 1; i <= len; i++)
		{
			BaseBall[i].ClearBall();
			BaseBall[i].Track = Pitcher.PitchBall[i];
			BaseBall[i].CustomiVelocity = get<1>(Main->CalculateDirection(BaseBall[i], Main->StrikeZoneSize, Main->min_velocity_angle, Main->ball_framefps));
			BaseBall[i].Track.Origin.velocity = EulerAngle(BaseBall[i].CustomiVelocity, Main->min_velocity_angle) * BaseBall[i].Track.Origin.velocity_length();

			BaseBall[i].CustomiSpin = ivec2(
				((int)(BaseBall[i].Track.Origin.spin_euler.x / PI * Main->min_spin_angle + 0.5f) + Main->min_spin_angle) % Main->min_spin_angle,
				((int)(BaseBall[i].Track.Origin.spin_euler.y / PI * Main->min_spin_angle + 0.5f) + Main->min_spin_angle * 2) % (Main->min_spin_angle * 2));
			BaseBall[i].ThrowBall(1.0f / Main->ball_framefps);

			Frequency[i] = Pitcher.PitchBall[i].Property.frequency;
			Proficiency[i] = Pitcher.PitchBall[i].Property.proficiency;
		}
		PitchCount = Pitcher.PitchCount;
	}
	else
	{
		MessageBox(NULL, L"���� ���� �ε��� �����߽��ϴ�!", L"Prism Pitch Perfection", 0);
	}
}

void CModeCustom::SaveFile(string FileName)
{
	FileName = "..\\bin\\pitcher\\" + FileName + ".pitcher";
	CPitcher Pitcher;
	CBallTrace tmpBall;
	int i;

	Pitcher.PitchBall.push_back(tmpBall);
	for (i = 1; i <= 7; i++)
	{
		if (BaseBall[i].Track.Origin.velocity_length() == 0) continue;

		tmpBall.Origin = BaseBall[i].Track.Origin;
		tmpBall.Property = BaseBall[i].Track.Property;
		tmpBall.Property.frequency = Frequency[i];
		tmpBall.Property.proficiency = Proficiency[i];

		Pitcher.PitchBall.push_back(tmpBall);
	}
	Pitcher.PitchCount = PitchCount;

	if (Pitcher.SavePitcher(FileName.c_str()))
	{
		MessageBox(NULL, L"���� ������ �����߽��ϴ�!", L"Prism Pitch Perfection", 0);
	}
	else
	{
		MessageBox(NULL, L"���� ���� ���忡 �����߽��ϴ�!", L"Prism Pitch Perfection", 0);
	}
}
