#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility

class CBallFactor
{
public:
    CBallFactor(void);
    ~CBallFactor(void);

public:
	dvec3 location;							// ball location
	dvec3 velocity;							// ball velocity
	dvec3 angle;							// ball initial angle
	double spin;							// ball spin
	dvec2 spin_euler;						// ball spin euler
	double spin_angle;						// ball spin angle (0~2pi)    dvec3 velocity_angle;

public:
	double velocity_length(void);
	dvec3 velocity_angle(void);

};
