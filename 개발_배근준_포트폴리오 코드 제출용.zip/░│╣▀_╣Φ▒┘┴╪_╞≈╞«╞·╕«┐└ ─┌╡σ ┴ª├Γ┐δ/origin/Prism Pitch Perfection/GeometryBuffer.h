#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility

using namespace std;

class CGeometryBuffer
{
public:
	CGeometryBuffer(void);
	~CGeometryBuffer(void);

public:
	int		size;
	GLenum	mode;
	GLuint	vertex_array;
	GLuint	vertex_buffer;
	GLuint	index_buffer;
	GLuint	program;

public:
	void InitBuffer(vector<vertex> v_Vertex, bool IsOrder, GLenum mode, GLuint program);
	void InitBuffer(vector<vertex> v_Vertex, vector<uint> indices, GLenum mode, GLuint program);
	void Draw(mat4 model_matrix);

};
