#pragma once
#include "ModeComponent.h"
#include "Pitcher.h"
#include "FileList.h"

class CModePitcher : public CModeComponent
{
public:
	CModePitcher(void);
	~CModePitcher(void);

public:
	CModeComponent* Main;
	CBall BaseBall;
	CPitcher Pitcher;
	CFileList PitcherList;
	int PitcherCursor; // ����
	int BallCursor; // ����
	double BoardCursor; // ����������
	double frameDelay; // �����ð�
	bool GageStatus;

	ivec2 CustomiVelocity;

	int Exception_SaveCustomBall = 0;
	double Proficiency = 0;
	int Frequency = 0;

public:
	void Initialize(void);
	void Update(void);
	void Render(void);
	void Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods);
	void Mouse(GLFWwindow* window, int button, int action, int mods);

	void Update_PitcherCustom(void);
	void Update_PitcherMinigame(void);

};
