#include "ModePitcher.h"
#include "Utility.h"


CModePitcher::CModePitcher(void)
{
}


CModePitcher::~CModePitcher(void)
{
}


void CModePitcher::Initialize(void)
{
	double rAccuracy;
	dvec2 rCourse;

	switch (Main->ProgramMode)
	{
	case 30: // Pitcher Mode, ������ ����Ʈ
		PitcherList = CFileList("..\\bin\\pitcher\\", "pitcher");
		PitcherList.GetList();

		PitcherCursor = 0;
		Main->move_camera_direction = false;
		mode_track = 1;
		break;

	case 31: // ���� ���� �ε�
		Main->Initialize_Camera(30);
		BaseBall.ClearBall();
		Pitcher.LoadPitcher((PitcherList.folder + PitcherList.FileList[PitcherCursor] + "." + PitcherList.extension).c_str(), BaseBall.Track.Property);
		Pitcher.Strength = 1.0f;

		// 1������ �Ѱ���� ���� ������ CustomiVelocity�� ����
		BallCursor = 1;
		BaseBall.Track = Pitcher.PitchBall[BallCursor];
		BaseBall.Track = Pitcher.UpdateCondition(BaseBall.Track);
		CustomiVelocity = get<1>(Main->CalculateDirection(BaseBall, Main->StrikeZoneSize, Main->min_velocity_angle, Main->ball_framefps));

		frameDelay = Main->t + 0.1f;

		break;

	case 32: // �� ������
		Main->ClearSchedule();

		BaseBall.ClearBall();
		Update_PitcherCustom();
		Main->move_camera_direction = true;
		BaseBall.BallZone_visible = true;

		Main->Set_PitcherMinigame(Pitcher.Strength);

		break;

	case 33: // ��ó �̴ϰ���
		BoardCursor = -1;

		BaseBall.BallZone_visible = false;

		frameDelay = Main->t + 1.0f;
		GageStatus = 0;

		break;

	case 34: // �� ���ư�����
		// �� ����
		// ������
		rAccuracy = Main->GetPitcherMinigameAccuracy(BoardCursor);
		if (rAccuracy == 0)
		{
			ivec2 tmp = get<1>(Main->CalculateDirection(BaseBall, Main->StrikeZoneSize, Main->min_velocity_angle, Main->ball_framefps));
			rCourse = dvec2(tmp.x, tmp.y), rAccuracy = 1;
		}
		else rCourse = dvec2(CustomiVelocity.x, CustomiVelocity.y);
		BaseBall.Track = Pitcher.RandomBall(BaseBall.Track, rCourse, rAccuracy);
		Proficiency = BaseBall.Track.Property.proficiency;
		Frequency = BaseBall.Track.Property.frequency;

		BaseBall.ThrowBall(1.0f / Main->ball_framefps);
		BaseBall.ResultStatus = BaseBall.ResultStrike;
		BaseBall.nowframe = Main->t;

		Main->SetSchedule(BaseBall, 0, 1.0f);
		BaseBall.balltype = 1;

		break;

	case 35: // �� ���� ���� ����
		break;
	}

}


void CModePitcher::Update(void)
{
	int Result;

	while (1)
	{
		Result = 0;

		switch (Main->ProgramMode)
		{
		case 30: // Pitcher Mode, ������ ����Ʈ
			break;

		case 31: // ���� ���� �ε�
			if (frameDelay <= Main->t) Main->ProgramMode = 32;
			break;

		case 32: // �� ������
			break;

		case 33: // ��ó �̴ϰ���
			Update_PitcherMinigame();
			break;

		case 34: // �� ���ư�����
			Result = Main->GetSchedule();
			switch (Result)
			{
			case 1:
				Main->Update_Ball(BaseBall);
				if (BaseBall.balltype == 2) Main->ProgramMode = 35;
				break;
			}

			break;

		case 35: // �� ���� ���� ����
			break;

		}

		if (Result == 0) break;
	}
}


void CModePitcher::Render(void)
{
	int i, len, tmpCursor;
	float dpi_scale, tmp, size;
	float a = abs(sin(Main->t) * 2.5f);
	vec3 Color;
	string szTextBall;
	char szText[1024];

	dpi_scale = cg_get_dpi_scale();

	switch (Main->ProgramMode)
	{
	case 30: // Pitcher Mode, ������ ����Ʈ
		Main->Render_Text("Pitcher List", 100, 50, 0.8f, vec4(0.5f, 0.8f, 0.2f, 1.0f), dpi_scale);
		len = PitcherList.FileList.size();
		if (len == 0)
		{
			MessageBox(NULL, L"���� ���� ������ �������� �ʽ��ϴ�!", L"Prism Pitch Perfection", 0);
			Main->ProgramMode = 0;
		}
		// 10������ ǥ��
		tmpCursor = PitcherCursor / 10;
		for (i = tmpCursor * 10; i < (tmpCursor + 1) * 10 && i < len; i++)
		{
			if (i == PitcherCursor) tmp = 1.0f, size = 0.6f;
			else tmp = 0.4f, size = 0.55f;
			Main->Render_Text(PitcherList.FileList[i].c_str(), 100, 100 + 30 * (i - tmpCursor * 10), size, vec4(0.5f, 0.7f, 0.7f, tmp), dpi_scale);
		}
		sprintf(szText, "%d / %d Pitcher", PitcherCursor + 1, PitcherList.FileList.size());
		Main->Render_Text(szText, 130, Main->window_size.y - 50, 0.3f, vec4(0.9f, 0.9f, 0.8f, 1.0f), 1.0f);
		glUseProgram(Main->Program);

		break;

	case 31: // ���� ���� �ε�
		break;

	case 32: // �� ������
		Main->Render_BaseBall(BaseBall);
		Main->Render_Stadium();

		// ��Ʈ����ũ���� ǥ�õ� �� ���
		Main->Render_BallZone(BaseBall, 2);

		if (mode_track == 1)
		{
			Main->Render_BallMovement(BaseBall);
		}

		Main->Render_Pitchboard(Pitcher, BallCursor);
		Main->Render_PitcherStrength(Pitcher.Strength);

		break;

	case 33: // ��ó �̴ϰ���
		Main->Render_Stadium(false);

		// �̴ϰ��� ǥ��
		Main->Render_PitchMinigame(BoardCursor);

		break;

	case 34: // �� ���ư�����
		Main->Render_BaseBall(BaseBall);
		Main->Render_Stadium(false);

		break;

	case 35: // �� ���� ���� ����
		Main->Render_Stadium();

		// ��Ʈ����ũ���� ǥ�õ� �� ���
		Main->Render_BallZone(BaseBall, BaseBall.ResultStrike);

		// ��Ʈ����ũ �� ���� ǥ��
		const char* szText[] = { "BALL", "STRIKE", "MISS SWING", "HIT" };
		Main->Render_Text(szText[BaseBall.ResultStatus], 20, 20, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);
		// ������ ���� ǥ��
		szTextBall = to_string((int)(BaseBall.Track.Origin.velocity_length() * 3600.0f / 1000.0f + 0.5));
		szTextBall += "km   ";
		szTextBall += BaseBall.Track.Property.name;

		Main->Render_Text(szTextBall, 20, 50, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);
		glUseProgram(Main->Program);

		break;
	}

}


void CModePitcher::Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	int tmp = 1;
	if (mods & GLFW_MOD_SHIFT) tmp = 10;

	switch (Main->ProgramMode)
	{
	case 30: // Pitcher Mode, ������ ����Ʈ
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE || key == GLFW_KEY_Q) Main->ProgramMode = 0; // Main
			else if (key == GLFW_KEY_UP)
			{
				PitcherCursor = (PitcherCursor - 1 + PitcherList.FileList.size()) % PitcherList.FileList.size();
			}
			else if (key == GLFW_KEY_DOWN)
			{
				PitcherCursor = (PitcherCursor + 1) % PitcherList.FileList.size();
			}
			else if (key == GLFW_KEY_PAGE_UP)
			{
				PitcherCursor -= 10;
				if (PitcherCursor - 1 < 0) PitcherCursor = 0;
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				PitcherCursor += 10;
				if (PitcherCursor >= PitcherList.FileList.size()) PitcherCursor = PitcherList.FileList.size() - 1;
			}
			else if (key == GLFW_KEY_ENTER)
			{
				Main->ProgramMode = 31;
			}
		}
		break;

	case 31: // ���� ���� �ε�
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
		}
		break;

	case 32: // �� ������
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_PAGE_UP) Main->Camera_Prev();
			else if (key == GLFW_KEY_PAGE_DOWN) Main->Camera_Next();
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_SPACE)
			{
				if (BaseBall.balltype == 0)
				{
					Main->ProgramMode = 33;
				}
			}
			else if (key == GLFW_KEY_T)
			{
				mode_track = (mode_track + 1) % 2;
			}
			else if (key == GLFW_KEY_W)
			{
				if (BaseBall.balltype == 0)
				{
					if (BallCursor - 1 >= 1)
					{
						BallCursor--;
						Update_PitcherCustom();
					}
				}
			}
			else if (key == GLFW_KEY_S)
			{
				if (BaseBall.balltype == 0)
				{
					if (BallCursor + 1 <= Pitcher.PitchBall.size() - 1)
					{
						BallCursor++;
						Update_PitcherCustom();
					}
				}
			}
			else if (key == GLFW_KEY_LEFT)
			{
				if (BaseBall.balltype == 0)
				{
					if ((Main->cam.eye-Main->cam.at).y >= 0)
					{
						if (CustomiVelocity.x <= Main->min_velocity_angle * 2 - tmp)
						{
							CustomiVelocity.x += tmp;
							Update_PitcherCustom();
						}
					}
					else
					{
						if (CustomiVelocity.x >= 0 + tmp)
						{
							CustomiVelocity.x -= tmp;
							Update_PitcherCustom();
						}
					}
				}
			}
			else if (key == GLFW_KEY_RIGHT)
			{
				if (BaseBall.balltype == 0)
				{
					if ((Main->cam.eye - Main->cam.at).y >= 0)
					{
						if (CustomiVelocity.x >= 0 + tmp)
						{
							CustomiVelocity.x -= tmp;
							Update_PitcherCustom();
						}
					}
					else
					{
						if (CustomiVelocity.x <= Main->min_velocity_angle * 2 - tmp)
						{
							CustomiVelocity.x += tmp;
							Update_PitcherCustom();
						}
					}
				}
			}
			else if (key == GLFW_KEY_UP)
			{
				if (BaseBall.balltype == 0)
				{
					if (CustomiVelocity.y >= 0 + tmp)
					{
						CustomiVelocity.y -= tmp;
						Update_PitcherCustom();
					}
				}
			}
			else if (key == GLFW_KEY_DOWN)
			{
				if (BaseBall.balltype == 0)
				{
					if (CustomiVelocity.y <= Main->min_velocity_angle * 2 - tmp)
					{
						CustomiVelocity.y += tmp;
						Update_PitcherCustom();
					}
				}
			}
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				//printf("BaseBall Speed (%g %g %g), ", BaseBall.Track.Origin.velocity.x, BaseBall.Track.Origin.velocity.y, BaseBall.Track.Origin.velocity.z);
				printf("CustomVelocity(%d %d)\n", CustomiVelocity.x, CustomiVelocity.y);
				//printf("CustomSpin(%g %g), ", Pitcher.PitchBall[BallCursor].angle.x, Pitcher.PitchBall[BallCursor].angle.y);
				//printf("Spin(%g %g %g)\n", BaseBall.Track.Origin.spin.x, BaseBall.Track.Origin.spin.y, BaseBall.Track.Origin.spin.z);
				printf("Camera.eye(%g %g %g), ", Main->cam.eye.x, Main->cam.eye.y, Main->cam.eye.z);
				printf("Camera.at(%g %g %g), ", Main->cam.at.x, Main->cam.at.y, Main->cam.at.z);
				printf("Camera.up(%g %g %g)\n", Main->cam.up.x, Main->cam.up.y, Main->cam.up.z);
			}
		}
		break;

	case 33: // ��ó �̴ϰ���
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_SPACE)
			{
				if (BoardCursor >= 0)
				{
					GageStatus = 1;
					frameDelay = Main->t + 1.0f;
				}
			}
		}
		break;

	case 34: // �� ���ư�����
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
		}
		break;

	case 35: // �� ���� ���� ����
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_PAGE_UP) Main->Camera_Prev();
			else if (key == GLFW_KEY_PAGE_DOWN) Main->Camera_Next();
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_SPACE)
			{
				Main->ProgramMode = 32;
			}
			else if (key == GLFW_KEY_1)
			{
				Exception_SaveCustomBall = 1;
			}
			else if (key == GLFW_KEY_2)
			{
				Exception_SaveCustomBall = 2;
			}
			else if (key == GLFW_KEY_3)
			{
				Exception_SaveCustomBall = 3;
			}
			else if (key == GLFW_KEY_4)
			{
				Exception_SaveCustomBall = 4;
			}
			else if (key == GLFW_KEY_5)
			{
				Exception_SaveCustomBall = 5;
			}
			else if (key == GLFW_KEY_6)
			{
				Exception_SaveCustomBall = 6;
			}
			else if (key == GLFW_KEY_7)
			{
				Exception_SaveCustomBall = 7;
			}
		}
		break;
	}
}


void CModePitcher::Mouse(GLFWwindow* window, int button, int action, int mods)
{
}


void CModePitcher::Update_PitcherCustom(void)
{
	BaseBall.Track = Pitcher.PitchBall[BallCursor];
	BaseBall.Track.Origin.velocity = EulerAngle(CustomiVelocity, Main->min_velocity_angle) * Pitcher.PitchBall[BallCursor].Origin.velocity_length();
	BaseBall.Track = Pitcher.UpdateCondition(BaseBall.Track);

	// printf("l(%g %g %g), v(%g: %g %g %g), s(%g: %g %g)\n", BaseBall.Track.Origin.location.x, BaseBall.Track.Origin.location.y, BaseBall.Track.Origin.location.z, BaseBall.Track.Origin.velocity.length(), BaseBall.Track.Origin.velocity.x, BaseBall.Track.Origin.velocity.y, BaseBall.Track.Origin.velocity.z, BaseBall.Track.Origin.spin, BaseBall.Track.Origin.spin_euler.x, BaseBall.Track.Origin.spin_euler.y);
	BaseBall.ThrowBall(1.0f / Main->ball_framefps, 0);
}


void CModePitcher::Update_PitcherMinigame(void)
{
	if (GageStatus == 0)
	{
		if (BoardCursor < 100)
		{
			if (frameDelay + 1.0f / Main->framefps <= Main->t)
			{
				if (BoardCursor < 0) BoardCursor = 0;
				while (frameDelay <= Main->t)
				{
					frameDelay += 1.0f / Main->framefps;
					BoardCursor += Main->PitcherCursorVelocity / Main->framefps * 100.0f;

					if (BoardCursor >= 100)
					{
						BoardCursor = 10000;
						frameDelay = Main->t + 1.0f;
						GageStatus = 1;
						break;
					}
				}
			}
		}
	}
	else if (Main->t >= frameDelay)
	{
		Main->ProgramMode = 34;
	}
}
