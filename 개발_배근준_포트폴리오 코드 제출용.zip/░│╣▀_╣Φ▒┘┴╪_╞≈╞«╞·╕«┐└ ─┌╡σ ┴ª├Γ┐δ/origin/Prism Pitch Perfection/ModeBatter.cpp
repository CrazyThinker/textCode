#include "ModeBatter.h"


extern double SlowMode;

CModeBatter::CModeBatter(void)
{
}


CModeBatter::~CModeBatter(void)
{
}


void CModeBatter::Initialize(void)
{
	switch (Main->ProgramMode)
	{
	case 20: // Batter Mode, ������ ����Ʈ
		PitcherList = CFileList("..\\bin\\pitcher\\", "pitcher");
		PitcherList.GetList();

		PitcherCursor = 0;
		Main->move_camera_direction = false;

		break;

	case 21: // ���̵� ���� �� ���� ���� �ε�
		Main->Initialize_Camera(20);
		BaseBall.ClearBall();
		Pitcher.LoadPitcher((PitcherList.folder + PitcherList.FileList[PitcherCursor] + "." + PitcherList.extension).c_str(), BaseBall.Track.Property);
		Pitcher.Strength = 1.0f;

		PitchSignType = 0;
		StanceCursor = 2;

		CursorDifficulty = 0;
		mode_track = 1;

		break;

	case 22: // �� ������
		// ��Ʈ �ʱ�ȭ
		Main->ClearSchedule();

		BaseBall.ClearBall();
		Bat.ClearBat();
		Bat.nowframe = 0;
		Main->move_camera_direction = false;
		Main->nowcam = 0;
		Main->Camera_Home();
		Main->nowframe = Main->t;
		break;

	case 23: // �� ���ư�����
		break;

	case 24: // ���� ��Ʈ�Ǿ� ���ư�����
		Main->move_camera_direction = true;
		break;

	case 25: // �� ����
		Main->move_camera_direction = true;
		break;

	case 26: // ���÷���
		Main->move_camera_direction = true;
		break;

	}

}


void CModeBatter::Update(void)
{
	int Result;

	while (1)
	{
		Result = 0;

		switch (Main->ProgramMode)
		{
		case 20: // Batter Mode, ������ ����Ʈ
			break;

		case 21: // ���̵� ���� �� ���� ���� �ε�
			break;

		case 22: // �� ������
			Main->Update_BatLocation(Bat);

			Result = Main->GetSchedule();

			switch (Result)
			{
			case 11:
				if (Bat.Type == 1)
				{
					Main->Update_Bat(Bat);

					if (Bat.Type == 2)
					{
						Main->SetSchedule(Main->t + 1.0f, 19);
					}
				}
				break;

			case 19:
				Bat.ClearBat();
				break;
			}
			break;

		case 23: // �� ���ư�����
			Main->Update_BatLocation(Bat);

			PitchSignType = Main->t + 1.0f - BaseBall.nowframe;
			if (PitchSignType > 1 || PitchSignType < 0) PitchSignType = 1;

			Result = Main->GetSchedule();
			switch (Result)
			{
			case 1:
				if (BaseBall.balltype == 1)
				{
					Main->Update_Ball(BaseBall);

					Main->CheckBatHit(BaseBall, Bat, Difficulty[dPowerfulSlugger] * 0.5f + 1); // �Ϲ�Ÿ�ڸ� 1.0��, ����Ÿ�ڸ� 1.5��
					if (BaseBall.balltype == 2)
					{
						Main->ProgramMode = 25;
					}
					else if (BaseBall.balltype == 3)
					{
						Replay_collisionnowframe = Main->t;
						BaseBall.nowframe = Main->t;
						Main->ProgramMode = 24;

						Main->RemoveSchedule(1);
						Main->SetSchedule(BaseBall, 2, 1.0f - Difficulty[dSlow] * SlowMode);
					}
				}

				break;

			case 11:
				if (Bat.Type == 1)
				{
					Main->Update_Bat(Bat);

					Main->CheckBatHit(BaseBall, Bat, Difficulty[dPowerfulSlugger] * 0.5f + 1); // �Ϲ�Ÿ�ڸ� 1.0��, ����Ÿ�ڸ� 1.5��
					if (BaseBall.balltype == 3)
					{
						Replay_collisionnowframe = Main->t;
						BaseBall.nowframe = Main->t;
						Main->ProgramMode = 24;

						Main->RemoveSchedule(1);
						Main->SetSchedule(BaseBall, 2, 1.0f - Difficulty[dSlow] * SlowMode);

					}

				}
				break;
			}

			break;

		case 24: // ���� ��Ʈ�Ǿ� ���ư�����
			Main->Update_BatLocation(Bat);

			Result = Main->GetSchedule();
			switch (Result)
			{
			case 2:
				if (BaseBall.balltype == 3)
				{
					Main->Update_Ball(BaseBall);
					if (BaseBall.balltype == 4)
					{
						Main->ProgramMode = 25;
					}
				}

				break;

			case 11:
				if (Bat.Type == 1)
				{
					Main->Update_Bat(Bat);
				}
				break;
			}
			break;

		case 25: // �� ����
			Main->Update_BatLocation(Bat);

			Result = Main->GetSchedule();
			switch (Result)
			{
			case 11:
				if (Bat.Type == 1)
				{
					Main->Update_Bat(Bat);
				}
				break;
			}

			if (BaseBall.nowframe <= Main->t)
			{
				PitchSignType = 0;
			}
			break;

		case 26: // ���÷���
			Result = Main->GetSchedule();

			switch (Result)
			{
			case 1:
				Main->Update_Ball(BaseBall);
				if (BaseBall.idxTrack <= idxReplay) BaseBall.Track.idxTrackMovement = BaseBall.idxTrack;

				break;

			case 2:
				BaseBall.balltype = 3;
				Main->Update_Ball(BaseBall);

				break;

			case 11:
				if (Bat.Type == 1)
				{
					Main->Update_Bat(Bat);
				}
				break;

			case 99:
				Main->ProgramMode = 25;
				break;

			}

			if (BaseBall.nowframe <= Main->t)
			{
				PitchSignType = 0;
			}
			break;

		}

		if (Result == 0) break;
	}
}


void CModeBatter::Render(void)
{
	int i, len, tmpCursor;
	float dpi_scale, tmp, size;
	float a = abs(sin(Main->t) * 2.5f);
	vec3 Color;
	string szString, szTextBall;
	char szText[1024];

	dpi_scale = cg_get_dpi_scale();

	switch (Main->ProgramMode)
	{
	case 20: // Batter Mode, ������ ����Ʈ
		Main->Render_Text("Pitcher List", 100, 50, 0.8f, vec4(0.5f, 0.8f, 0.2f, 1.0f), dpi_scale);
		len = PitcherList.FileList.size();
		if (len == 0)
		{
			MessageBox(NULL, L"���� ���� ������ �������� �ʽ��ϴ�!", L"Prism Pitch Perfection", 0);
			Main->ProgramMode = 0;
		}
		// 10������ ǥ��
		tmpCursor = PitcherCursor / 10;
		for (i = tmpCursor * 10; i < (tmpCursor + 1) * 10 && i < len; i++)
		{
			if (i == PitcherCursor) tmp = 1.0f, size = 0.6f;
			else tmp = 0.4f, size = 0.55f;
			Main->Render_Text(PitcherList.FileList[i].c_str(), 100, 100 + 30 * (i % 10), size, vec4(0.5f, 0.7f, 0.7f, tmp), dpi_scale);
		}
		sprintf(szText, "%d / %d Pitcher", PitcherCursor + 1, PitcherList.FileList.size());
		Main->Render_Text(szText, 130, Main->window_size.y - 50, 0.3f, vec4(0.9f, 0.9f, 0.8f, 1.0f), 1.0f);
		glUseProgram(Main->Program);

		break;

	case 21: // ���̵� ���� �� ���� ���� �ε�
		Main->Render_Text("Select Difficulty", 100, 70, 0.8f, vec4(0.5f, 0.8f, 0.2f, 1.0f), dpi_scale);

		i = 0;
		if (i == CursorDifficulty) tmp = 1.0f, size = 0.4f;
		else tmp = 0.4f, size = 0.35f;
		Main->Render_Text(strDifficulty[0], 100, 120 + 30 * i, size, vec4(0.7f, 0.5f, 0.7f, tmp), dpi_scale);

		for (i = 1; i <= nDifficulty; i++)
		{
			if (i == CursorDifficulty) tmp = 1.0f, size = 0.4f;
			else tmp = 0.4f, size = 0.35f;
			if (Difficulty[i] == 1) szString = "O";
			else szString = "X";
			Main->Render_Text(szString + "  " + strDifficulty[i], 100, 120 + 30 * i, size, vec4(0.5f, 0.7f, 0.7f, tmp), dpi_scale);
		}
		glUseProgram(Main->Program);
		break;

	case 22: // �� ������
		Main->Render_Stadium();
		Main->Render_PitchSign(PitchSignType);
		Main->Render_StanceMode(StanceCursor);

		if (Bat.Type == 0)
		{
			// Bat Preview ǥ��
			Main->Render_Bat(Bat, true);
		}
		Main->Render_Bat(Bat);
		Main->Render_PitcherStrength(Pitcher.Strength);
		break;

	case 23: // �� ���ư�����
		Main->Render_Stadium(0);

		if (Difficulty[dGuide] == 1) Main->Render_BattingGuide(BaseBall);
		if (BaseBall.nowframe <= Main->t)
		{
			Main->Render_BaseBall(BaseBall);
		}
		Main->Render_PitchSign(PitchSignType);

		if (Bat.Type == 0)
		{
			// Bat Preview ǥ��
			Main->Render_Bat(Bat, true);
		}
		Main->Render_Bat(Bat);

		if (Difficulty[dShowBallType] == 1 && BaseBall.nowframe >= Main->t + 0.5f)
		{
			szTextBall += BaseBall.Track.Property.name;

			this->Render_Text(szTextBall, 50, 50, 0.4f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);
			glUseProgram(Main->Program);
		}

		break;

	case 24: // ���� ��Ʈ�Ǿ� ���ư�����
		Main->Render_Stadium();

		Main->Render_BaseBall(BaseBall);
		if (mode_track != 0)
		{
			Main->Render_BallMovement(BaseBall);
		}

		if (Bat.Type == 0)
		{
			// Bat Preview ǥ��
			Main->Render_Bat(Bat, true);
		}
		Main->Render_Bat(Bat);

		break;

	case 25: // �� ����
		Main->Render_Stadium();
		if (BaseBall.balltype < 3)
		{
			Main->Render_PitchSign(PitchSignType);
			Main->Render_BallZone(BaseBall, BaseBall.ResultStrike);
		}
		else
		{
			Main->Render_BaseBall(BaseBall);
		}

		if (mode_track == 2)
		{
			int tmp = BaseBall.balltype;

			BaseBall.balltype = 1;
			Main->Render_BallMovement(BaseBall);
			BaseBall.balltype = tmp;
		}
		if (BaseBall.balltype >= 3 && mode_track != 0)
		{
			Main->Render_BallMovement(BaseBall);
		}

		if (Bat.Type == 0)
		{
			// Bat Preview ǥ��
			Main->Render_Bat(Bat, true);
		}
		Main->Render_Bat(Bat);

		if (BaseBall.balltype == 2)
		{
			// ��Ʈ����ũ �� ���� ǥ��
			const char* szText[] = { "BALL", "STRIKE", "MISS SWING" };
			Main->Render_Text(szText[BaseBall.ResultStatus], 20, 20, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);

			// ������ ���� ǥ��
			this->Render_Text(ResultText, 20, 50, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);
			glUseProgram(Main->Program);
		}
		else if (BaseBall.balltype == 4)
		{
			int iszText;
			const char* szText[] = { "FOUL", "INFIELD", "NICE HIT", "HOME RUN!"};
			char szDistance[30] = "";
			dvec3 location = BaseBall.TrackCollision[BaseBall.TrackCollision.Track.size() - 1].location;
			if (location.y < 0 || (location.x - location.y) * (location.x + location.y) >= 0) iszText = 0; // �Ŀ�üũ
			else if (BaseBall.CollisionDistance.length() < 36.88f) iszText = 1; // ���ʵ�
			else if ((BaseBall.CollisionDistance - dvec3(0, -5, 0)).length() < 120.0f) iszText = 2, sprintf(szDistance, "%dM ", (int)(BaseBall.CollisionDistance.length() + 0.5f)); // Ȩ��
			else iszText = 3, sprintf(szDistance, "%dM ", (int)(BaseBall.CollisionDistance.length() + 0.5f));

			strcat(szDistance, szText[iszText]);
			// ��Ʈ����ũ �� ���� ǥ��
			Main->Render_Text(szDistance, 20, 20, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);

			// ������ ���� ǥ��
			this->Render_Text(ResultText, 20, 50, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);
			glUseProgram(Main->Program);

		}
		break;

	case 26: // ���÷���
		Main->Render_Stadium(0);

		if (BaseBall.nowframe <= Main->t)
		{
			Main->Render_BaseBall(BaseBall);

			if (mode_track == 2)
			{
				int tmp = BaseBall.balltype;

				BaseBall.balltype = 1;
				Main->Render_BallMovement(BaseBall);
				BaseBall.balltype = tmp;
			}
			if (BaseBall.balltype >= 3 && mode_track != 0)
			{
				Main->Render_BallMovement(BaseBall);
			}
		}


		Main->Render_Bat(Bat);

		this->Render_Text("Replay", Main->window_size.x - 80, 30, 0.3f, vec4(0.95f, 0.95f, 0.95f, 1), dpi_scale);
		glUseProgram(Main->Program);

		break;

	}
}


void CModeBatter::Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	switch (Main->ProgramMode)
	{
	case 20: // Batter Mode, ������ ����Ʈ
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_UP)
			{
				PitcherCursor = (PitcherCursor - 1 + PitcherList.FileList.size()) % PitcherList.FileList.size();
			}
			else if (key == GLFW_KEY_DOWN)
			{
				PitcherCursor = (PitcherCursor + 1) % PitcherList.FileList.size();
			}
			else if (key == GLFW_KEY_PAGE_UP)
			{
				PitcherCursor -= 10;
				if (PitcherCursor - 1 < 0) PitcherCursor = 0;
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				PitcherCursor += 10;
				if (PitcherCursor >= PitcherList.FileList.size()) PitcherCursor = PitcherList.FileList.size() - 1;
			}
			else if (key == GLFW_KEY_ENTER)
			{
				Main->ProgramMode = 21;
			}
		}
		break;

	case 21: // ���̵� ���� �� ���� ���� �ε�
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 20;
			}
			else if (key == GLFW_KEY_UP)
			{
				if (CursorDifficulty - 1 >= 0) CursorDifficulty--;
			}
			else if (key == GLFW_KEY_DOWN)
			{
				if (CursorDifficulty + 1 <= nDifficulty) CursorDifficulty++;
			}
			else if (key == GLFW_KEY_ENTER || key == GLFW_KEY_SPACE)
			{
				if (CursorDifficulty == 0)
				{
					// ��Ʈ ������ ���⼭!
					if (Difficulty[dBigBat] == 0) Bat.BatType = 1;
					else Bat.BatType = 2;
					Bat.BatThick = Main->BatInfo[Bat.BatType].Thick;
					Bat.BatLength = Main->BatInfo[Bat.BatType].Length;
					Bat.SweetSpotZone = Main->BatInfo[Bat.BatType].SweetSpotZone;
					Bat.StanceMode = StanceCursor;
					Bat.InitBat();

					Main->ProgramMode = 22;
				}
				else Difficulty[CursorDifficulty] = !Difficulty[CursorDifficulty];
			}
		}
		break;

	case 22: // �� ������
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_SPACE)
			{
				if (Bat.Type == 0)
				{
					double rAccuracy;
					dvec2 rCourse;

					Main->Set_PitcherMinigame(Pitcher.Strength);
					// �� ����
					PitchSignType = 1;
					// ����
					int BallCursor = Pitcher.RandomBallType();
					tuple<ivec2, ivec2, ivec2> iVelocity;

					BaseBall.Track = Pitcher.PitchBall[BallCursor];

					// �����
					BaseBall.Track = Pitcher.UpdateCondition(BaseBall.Track);

					// CustomiVelocity�� ���
					iVelocity = Main->CalculateDirection(BaseBall, Main->StrikeZoneSize, Main->min_velocity_angle, Main->ball_framefps);

					// ������
					rAccuracy = Main->RandomAccuracy(0);
					if (rAccuracy == 0) rCourse = dvec2(get<1>(iVelocity).x, get<1>(iVelocity).y), rAccuracy = 1;
					else rCourse = Pitcher.RandomCourse(iVelocity, BallCursor);
					BaseBall.Track = Pitcher.RandomBall(BaseBall.Track, rCourse, rAccuracy);

					Proficiency = BaseBall.Track.Property.proficiency;
					Frequency = BaseBall.Track.Property.frequency;

					BaseBall.BallZone_visible = false;
					BaseBall.ThrowBall(1.0f / Main->ball_framefps);
					BaseBall.ResultStatus = BaseBall.ResultStrike;

					//GetRotationMatrix(BaseBall.angle);
					BaseBall.nowframe = Main->t + (rand() % 151 + 150) / 100.0f;
					//BaseBall.nowframe = Main->t + 1.5f;
					Main->SetSchedule(BaseBall, 0, 1.0f - Difficulty[dSlow] * SlowMode);

					Replay_ballnowframe = BaseBall.nowframe;

					ResultText = to_string((int)(BaseBall.Track.Origin.velocity_length() * 3600.0f / 1000.0f + 0.5f));
					ResultText += "km   ";
					ResultText += BaseBall.Track.Property.name;

					BaseBall.balltype = 1;
					Main->ProgramMode = 23;
				}
			}
			else if (key == GLFW_KEY_TAB)
			{
				if (Bat.Type == 0)
				{
					Bat.IsRightBatter = !Bat.IsRightBatter;
					Bat.InitBat();
					Main->Update_BatLocation(Bat);
				}
			}
			else if (key == GLFW_KEY_W)
			{
				if (StanceCursor - 1 >= 1)
				{
					StanceCursor--;
					Bat.StanceMode = StanceCursor;
					Bat.InitBat();
					Main->Update_BatLocation(Bat);
				}
			}
			else if (key == GLFW_KEY_S)
			{
				if (StanceCursor + 1 <= nStanceMode)
				{
					StanceCursor++;
					Bat.StanceMode = StanceCursor;
					Bat.InitBat();
					Main->Update_BatLocation(Bat);
				}
			}
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				dvec2 pos; glfwGetCursorPos(Main->Window, &pos.x, &pos.y);
				printf("window_size(%d, %d), pos(%g, %g)\n", Main->window_size.x, Main->window_size.y, pos.x, pos.y);
				printf("s_x(%d %d), s_y(%d %d)\n", Main->StrikeZonePoint_x.x, Main->StrikeZonePoint_x.y, Main->StrikeZonePoint_y.x, Main->StrikeZonePoint_y.y);

				//dvec3 tmp = EulerAngle(Bat.Track.spin_euler);
				//printf("\nEnuler Angle(%g %g %g)\n", tmp.x, tmp.y, tmp.z);
			}
		}
		break;

	case 23: // �� ���ư�����
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				dvec2 pos; glfwGetCursorPos(Main->Window, &pos.x, &pos.y);
				printf("window_size(%d, %d), pos(%g, %g)\n", Main->window_size.x, Main->window_size.y, pos.x, pos.y);
			}
		}
		break;

	case 24: // ���� ��Ʈ�Ǿ� ���ư�����
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_PAGE_UP)
			{
				Main->Camera_Prev();
				if (!Bat.IsRightBatter + 1 == Main->nowcam) Main->Camera_Prev();
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				Main->Camera_Next();
				if (!Bat.IsRightBatter + 1 == Main->nowcam) Main->Camera_Next();
			}
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_T)
			{
				mode_track = (mode_track + 1) % 3;
			}
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				/*printf("Location(%g %g %g), ", BaseBall.Track.Origin.location.x, BaseBall.Track.Origin.location.y, BaseBall.Track.Origin.location.z);
				printf("Velocity %g (%g %g %g), ", BaseBall.Track.Origin.velocity.length(), BaseBall.Track.Origin.velocity.x, BaseBall.Track.Origin.velocity.y, BaseBall.Track.Origin.velocity.z);
				printf("Spin(%g) ", BaseBall.Track.Origin.spin);
				printf("SpinEuler(%g %g) ", BaseBall.Track.Origin.spin_euler.x, BaseBall.Track.Origin.spin_euler.y);
				printf("SpinAngle(%g)\n", BaseBall.Track.Origin.spin_angle);*/
			}
		}
		break;

	case 25: // �� ����
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_PAGE_UP)
			{
				Main->Camera_Prev();
				if (!Bat.IsRightBatter + 1 == Main->nowcam) Main->Camera_Prev();
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				Main->Camera_Next();
				if (!Bat.IsRightBatter + 1 == Main->nowcam) Main->Camera_Next();
			}
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_T)
			{
				mode_track = (mode_track + 1) % 3;
			}
			else if (key == GLFW_KEY_SPACE)
			{
				if (PitchSignType == 0)
				{
					Main->ProgramMode = 22;
				}
			}
			else if (key == GLFW_KEY_1)
			{
				Exception_SaveCustomBall = 1;
			}
			else if (key == GLFW_KEY_2)
			{
				Exception_SaveCustomBall = 2;
			}
			else if (key == GLFW_KEY_3)
			{
				Exception_SaveCustomBall = 3;
			}
			else if (key == GLFW_KEY_4)
			{
				Exception_SaveCustomBall = 4;
			}
			else if (key == GLFW_KEY_5)
			{
				Exception_SaveCustomBall = 5;
			}
			else if (key == GLFW_KEY_6)
			{
				Exception_SaveCustomBall = 6;
			}
			else if (key == GLFW_KEY_7)
			{
				Exception_SaveCustomBall = 7;
			}
			else if (key == GLFW_KEY_R)
			{
				idxReplay = BaseBall.Track.idxTrackMovement;

				BaseBall.nowframe = Main->t + 1.0f;
				Bat.nowframe = BaseBall.nowframe + Replay_batnowframe - Replay_ballnowframe;

				BaseBall.balltype = 0;
				Main->ClearSchedule();

				if (Bat.Type == 0) // ������
				{
					Main->SetSchedule(BaseBall, 0, 1.0f - Difficulty[dSlow] * SlowMode);
				}
				else if(BaseBall.idxTrackCollision == 0) // �꽺��
				{
					Main->SetSchedule(BaseBall, 0, 1.0f - Difficulty[dSlow] * SlowMode);
					Main->SetSchedule(Bat);
				}
				else // Ÿ��
				{
					Main->SetSchedule(BaseBall, 1, 1.0f - Difficulty[dSlow] * SlowMode);
					Main->SetSchedule(Bat);
					BaseBall.nowframe += Replay_collisionnowframe - Replay_ballnowframe;
					Main->SetSchedule(BaseBall, 2, 1.0f);
					BaseBall.nowframe = Main->t + 1.0f;
				}
				Main->SetSchedule(Main->Schedule.back().first + BaseBall.Track.Property.frame, 99); // ������

				BaseBall.balltype = 1;
				if (Bat.Type == 2) Bat.Type = 1;
				else Bat.Type = 0;
				BaseBall.idxTrack = 0;
				BaseBall.idxTrackCollision = 0;
				Bat.idxTrack = 0;

				Main->ProgramMode = 26;
			}
			else if (mods & GLFW_MOD_ALT && key == GLFW_KEY_P)
			{
				/*printf("Location(%g %g %g), ", BaseBall.Track.Origin.location.x, BaseBall.Track.Origin.location.y, BaseBall.Track.Origin.location.z);
				printf("Velocity %g (%g %g %g), ", BaseBall.Track.Origin.velocity.length(), BaseBall.Track.Origin.velocity.x, BaseBall.Track.Origin.velocity.y, BaseBall.Track.Origin.velocity.z);
				printf("Spin(%g) ", BaseBall.Track.Origin.spin);
				printf("SpinEuler(%g %g) ", BaseBall.Track.Origin.spin_euler.x, BaseBall.Track.Origin.spin_euler.y);
				printf("SpinAngle(%g)\n", BaseBall.Track.Origin.spin_angle);*/
			}
		}
		break;

	case 26: // ���÷���
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE)
			{
				Main->ProgramMode = 0;
			}
			else if (key == GLFW_KEY_PAGE_UP)
			{
				Main->Camera_Prev();
				if (!Bat.IsRightBatter + 1 == Main->nowcam) Main->Camera_Prev();
			}
			else if (key == GLFW_KEY_PAGE_DOWN)
			{
				Main->Camera_Next();
				if (!Bat.IsRightBatter + 1 == Main->nowcam) Main->Camera_Next();
			}
			else if (key == GLFW_KEY_HOME) Main->Camera_Home();
			else if (key == GLFW_KEY_T)
			{
				mode_track = (mode_track + 1) % 3;
			}
		}
	}
}


void CModeBatter::Mouse(GLFWwindow* window, int button, int action, int mods)
{
	switch (Main->ProgramMode)
	{
	case 22:
		if (button == GLFW_MOUSE_BUTTON_LEFT) // ����
		{
			if (action == GLFW_PRESS) // ���콺 Ŭ��
			{
				dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
				vec2 npos = cursor_to_ndc(pos, Main->window_size);

				if (Bat.Type == 0 && Main->EmptySchedule())
				{
					Bat.Swing(Main->t, 1.0f / Main->ball_framefps);
					Bat.Type = 1;
					Main->SetSchedule(Bat);
				}
			}
		}
		break;

	case 23:
		if (button == GLFW_MOUSE_BUTTON_LEFT) // ����
		{
			if (action == GLFW_PRESS) // ���콺 Ŭ��
			{
				dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
				vec2 npos = cursor_to_ndc(pos, Main->window_size);

				Bat.Swing(Main->t, 1.0f / Main->ball_framefps);
				Bat.Type = 1;
				BaseBall.ResultStatus = 2;

				Main->SetSchedule(Bat);

				Replay_batnowframe = Bat.nowframe;
			}
			else if (action == GLFW_RELEASE) // ���콺 ��
			{
				dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
				vec2 npos = cursor_to_ndc(pos, Main->window_size);
			}
		}
		break;
	}
}
