#include "ModeMain.h"
#include "Utility.h"

#define CASE_CUSTOM case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
#define CASE_BATTER case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
#define CASE_PITCHER case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39:


CModeMain::CModeMain(void)
{
}


CModeMain::~CModeMain(void)
{
}


void CModeMain::Initialize_Main(void)
{
	// Opening
	ProgramMode = beforeProgramMode = 0;

	ModeOpening.Main = this;
	ModeCustom.Main = this;
	ModeBatter.Main = this;
	ModePitcher.Main = this;
	Initialize_Vertex();
	Initialize_Bat();

	ModeOpening.Initialize();
}


void CModeMain::Initialize(void)
{
	if (ProgramMode != beforeProgramMode) beforeProgramMode = ProgramMode;
	else return;

	switch (ProgramMode)
	{
	// Opening
	case 0:
		ModeOpening.Initialize();
		break;

	// Help
	case 1:
		break;

	// Custom Mode
	CASE_CUSTOM
		ModeCustom.Initialize();
		break;

	// Batter Mode
	CASE_BATTER
		ModeBatter.Initialize();
		break;

	// Pitcher Mode
	CASE_PITCHER
		ModePitcher.Initialize();
		break;

	default:
		return;
	}

}


void CModeMain::Render(void)
{
	if (t < nowframe) return;
	nowframe = t + 1.0f / framefps;

	// clear screen (with background color) and clear depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// notify GL that we use our own program
	glUseProgram(Program);

	float dpi_scale, tmp, size;

	dpi_scale = cg_get_dpi_scale();

	switch (ProgramMode)
	{
	// Opening
	case 0:
		ModeOpening.Render();
		break;

	// Help
	case 1:
		//Render_Text("Made by Geun-Jun Bae", 150, 350, 0.4f, vec4(1.0f, 1.0f, 0.0f, 1.0f), dpi_scale);
		//glUseProgram(Program);

		break;

	// Custom Mode
	CASE_CUSTOM
		ModeCustom.Render();
		break;

	// Batter Mode
	CASE_BATTER
		ModeBatter.Render();
		break;

	// Pitcher Mode
	CASE_PITCHER
		ModePitcher.Render();
		break;

	default:
		return;

	}

	glfwSwapBuffers(Window);
}


void CModeMain::Update(void)
{
	switch (ProgramMode)
	{
	case -100: // Exit
		glfwSetWindowShouldClose(Window, GL_TRUE);
		break;

	// Opening
	case 0:
		ModeOpening.Update();
		break;

	// Help
	case 1:
		break;

	// Custom Mode
	CASE_CUSTOM
		ModeCustom.Update();
		break;

	// Batter Mode
	CASE_BATTER
		ModeBatter.Update();
		break;

	// Pitcher Mode
	CASE_PITCHER
		ModePitcher.Update();
		break;

	default:
		return;

	}
}


void CModeMain::Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	int ModeResult;

	switch (ProgramMode)
	{
	// Opening
	case 0:
		ModeOpening.Keyboard(window, key, scancode, action, mods);
		break;

	case 1:
		if (action == GLFW_PRESS)
		{
			if (key == GLFW_KEY_ESCAPE || key == GLFW_KEY_Q) ProgramMode = 0; // Exit
			break;
		}
		break;

	// Custom Mode
	CASE_CUSTOM
		ModeCustom.Keyboard(window, key, scancode, action, mods);
		break;

	// Batter Mode
	CASE_BATTER
		ModeBatter.Keyboard(window, key, scancode, action, mods);
		break;

	// Pitcher Mode
	CASE_PITCHER
		ModePitcher.Keyboard(window, key, scancode, action, mods);
		break;

	default:
		return;

	}
}


void CModeMain::Mouse(GLFWwindow* window, int button, int action, int mods)
{
	switch (ProgramMode)
	{
	// Exit
	case -100:
		glfwSetWindowShouldClose(Window, GL_TRUE);
		break;

	// Opening
	case 0:
		ModeOpening.Mouse(window, button, action, mods);
		break;

	// Help
	case 1:
		break;

	// Custom Mode
	CASE_CUSTOM
		ModeCustom.Mouse(window, button, action, mods);
	break;

	// Batter Mode
	CASE_BATTER
		ModeBatter.Mouse(window, button, action, mods);
	break;

	}
}


void CModeMain::Exception(void)
{
	switch (ProgramMode)
	{
		CASE_BATTER
			if (ModeBatter.Exception_SaveCustomBall) // Ÿ�ڸ�忡�� F1~F7 ������ �ش� �� ���� ���
			{
				ModeCustom.BaseBall[ModeBatter.Exception_SaveCustomBall].Track.Origin = ModeBatter.BaseBall.Track.Origin;
				ModeCustom.BaseBall[ModeBatter.Exception_SaveCustomBall].ThrowBall(1.0f / ball_framefps, 0);
				ModeCustom.BaseBall[ModeBatter.Exception_SaveCustomBall].CustomiVelocity = aEulerAngle(ModeBatter.BaseBall.Track.Origin.velocity, min_velocity_angle);
				ModeCustom.BaseBall[ModeBatter.Exception_SaveCustomBall].CustomiSpin = ivec2(
					((int)(ModeBatter.BaseBall.Track.Origin.spin_euler.x / PI * min_spin_angle + 0.5f) + min_spin_angle) % min_spin_angle,
					((int)(ModeBatter.BaseBall.Track.Origin.spin_euler.y / PI * min_spin_angle + 0.5f) + min_spin_angle * 2) % (min_spin_angle * 2));
				strcpy(ModeCustom.BaseBall[ModeBatter.Exception_SaveCustomBall].Track.Property.name, ModeBatter.BaseBall.Track.Property.name);
				ModeCustom.Proficiency[ModeBatter.Exception_SaveCustomBall] = ModeBatter.Proficiency;
				ModeCustom.Frequency[ModeBatter.Exception_SaveCustomBall] = ModeBatter.Frequency;
				printf("- Save ball information in %dth ball.\n", ModeBatter.Exception_SaveCustomBall);
				ModeBatter.Exception_SaveCustomBall = 0;
			}
		break;

		CASE_PITCHER
			if (ModePitcher.Exception_SaveCustomBall) // ������忡�� F1~F7 ������ �ش� �� ���� ���
			{
				ModeCustom.BaseBall[ModePitcher.Exception_SaveCustomBall].Track.Origin = ModePitcher.BaseBall.Track.Origin;
				ModeCustom.BaseBall[ModePitcher.Exception_SaveCustomBall].ThrowBall(1.0f / ball_framefps, 0);
				ModeCustom.BaseBall[ModePitcher.Exception_SaveCustomBall].CustomiVelocity = aEulerAngle(ModePitcher.BaseBall.Track.Origin.velocity, min_velocity_angle);
				ModeCustom.BaseBall[ModePitcher.Exception_SaveCustomBall].CustomiSpin = ivec2(
					((int)(ModePitcher.BaseBall.Track.Origin.spin_euler.x / PI * min_spin_angle + 0.5f) + min_spin_angle) % min_spin_angle,
					((int)(ModePitcher.BaseBall.Track.Origin.spin_euler.y / PI * min_spin_angle + 0.5f) + min_spin_angle * 2) % (min_spin_angle * 2));
				strcpy(ModeCustom.BaseBall[ModePitcher.Exception_SaveCustomBall].Track.Property.name, ModePitcher.BaseBall.Track.Property.name);
				ModeCustom.Proficiency[ModePitcher.Exception_SaveCustomBall] = ModePitcher.Proficiency;
				ModeCustom.Frequency[ModePitcher.Exception_SaveCustomBall] = ModePitcher.Frequency;
				printf("- Save ball information in %dth ball.\n", ModePitcher.Exception_SaveCustomBall);
				ModePitcher.Exception_SaveCustomBall = 0;
			}
		break;
	}
}
