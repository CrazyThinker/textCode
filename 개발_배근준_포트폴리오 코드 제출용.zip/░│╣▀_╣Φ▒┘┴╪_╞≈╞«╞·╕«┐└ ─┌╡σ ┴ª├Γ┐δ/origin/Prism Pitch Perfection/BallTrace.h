#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility
#include "trackball.h"	// virtual trackball

#include "BallFactor.h"
#include "BallProperty.h"

using namespace std;

class CBallTrace
{
public:
	CBallTrace(void);
	CBallTrace(double size, double mass, CBallFactor origin, double frame);
	~CBallTrace(void);
	CBallTrace& operator = (CBallTrace BallTrace);
	CBallFactor& operator [] (int idx);

public:
	CBallProperty Property;
	CBallFactor Origin;

public:
	vector<CBallFactor> Track;

	int idxTrackMovement = 0;

public:
	void CalculateTrack(double End = -2.655f);
	CBallFactor PredictTrack_y(double location_y);

private:
	dvec3 ForceGrav(CBallFactor Trace);					// �߷�
	dvec3 ForceDrag(CBallFactor Trace);					// �������׷�, ���״�����
	dvec3 ForceMagn(CBallFactor Trace);					// ȸ����
	//dvec3 ForceStitch(CTraceFactor Trace);			// �ǹ�
	dvec3 CalculateForce(CBallFactor Trace);			// ��� �� ���

};
