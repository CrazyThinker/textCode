#include "BallProperty.h"


CBallProperty::CBallProperty(void)
{
	name[0] = 0;
	frequency = 0;
	proficiency = 0;
	size = 0;
	mass = 0;
	frame = 0;
}


CBallProperty::~CBallProperty(void)
{
}


CBallProperty& CBallProperty::operator = (CBallProperty BallProperty)
{
	strcpy(this->name, BallProperty.name);
	this->frequency = BallProperty.frequency;
	this->proficiency = BallProperty.proficiency;
	this->size = BallProperty.size;
	this->mass = BallProperty.mass;
	this->frame = BallProperty.frame;

	this->g = BallProperty.g;
	this->C_d = BallProperty.C_d;
	this->C_l = BallProperty.C_l;
	this->e_v = BallProperty.e_v;
	this->e_g = BallProperty.e_g;

	return *this;
}


bool CBallProperty::operator == (CBallProperty Factor) const
{
	return strcmp(this->name, Factor.name) == 0
		&& this->frequency == Factor.frequency
		&& this->proficiency == Factor.proficiency
		&& this->size == Factor.size
		&& this->mass == Factor.mass
		&& this->frame == Factor.frame;
}


bool CBallProperty::operator != (CBallProperty Factor) const
{
	return strcmp(this->name, Factor.name) != 0
		|| this->frequency != Factor.frequency
		|| this->proficiency != Factor.proficiency
		|| this->size != Factor.size
		|| this->mass != Factor.mass
		|| this->frame != Factor.frame;
}



void CBallProperty::InitProperty(double size, double mass, double frame)
{
	this->size = size;
	this->mass = mass;
	this->frame = frame;

}
