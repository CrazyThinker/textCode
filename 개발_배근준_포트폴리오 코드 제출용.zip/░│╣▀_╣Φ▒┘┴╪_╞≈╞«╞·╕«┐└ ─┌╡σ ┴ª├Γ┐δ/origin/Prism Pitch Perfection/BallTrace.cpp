#include "BallTrace.h"
#include "BallProperty.h"
#include "Utility.h"


//extern uint	max_longitude;				// max longitude
extern CBallProperty tmpProperty;


CBallTrace::CBallTrace(void)
{
}


CBallTrace::CBallTrace(double size, double mass, CBallFactor origin, double frame)
{
	Property.size = size;
	Property.mass = mass;
	Origin = origin;
	Property.frame = frame;
}


CBallTrace::~CBallTrace(void)
{
}


CBallTrace& CBallTrace::operator = (CBallTrace BallTrace) // Track ���� ����
{
	this->idxTrackMovement = BallTrace.idxTrackMovement;
	this->Origin = BallTrace.Origin;
	this->Property = BallTrace.Property;

	return *this;
}


CBallFactor& CBallTrace::operator [] (int idx)
{
	if (0 <= idx && idx < Track.size()) return Track[idx];
	else return Track[0];
}



void CBallTrace::CalculateTrack(double End)
{
	int i;
	CBallFactor Factor = Origin;

	if (Property.frame == 0) return;

	Track.push_back(Origin);
	for (i = Track.size();; i++)
	{
		dvec3 acc = CalculateForce(Track[i - 1]) / Property.mass;

		Factor.velocity = Track[i - 1].velocity + acc * Property.frame;
		Factor.location = Track[i - 1].location + (Track[i - 1].velocity + Factor.velocity) / 2 * Property.frame;
		Factor.spin_angle = Track[i - 1].spin_angle + Factor.spin * Property.frame;
		if (Factor.spin_angle >= 2 * PI) Factor.spin_angle -= 2 * PI; if (Factor.spin_angle < 0) Factor.spin_angle += 2 * PI;

		Track.push_back(Factor);
		if (Factor.location.y <= End || Factor.location.z < 0) break;
		else if (Factor.location.y >= 0) idxTrackMovement = i;
		//printf("(%g %g %g)\n", Factor.spin_angle, Factor.spin_euler.x - PI / 2, Factor.spin_euler.y);
		//printf("(%g %g %g %g)\n", Factor.velocity, Factor.velocity_angle.x, Factor.velocity_angle.y, Factor.velocity_angle.z);
	}

	Factor = PredictTrack_y(End);
	if (Factor.velocity_length()) Track[i] = Factor;
}


CBallFactor CBallTrace::PredictTrack_y(double location_y)
{
	int i, n;
	double a, b;
	CBallFactor Result, Before, After;

	if (Property.frame == 0) return Result;

	n = Track.size();
	for (i = 1; i < n; i++) if ((Track[i - 1].location.y - location_y) * (Track[i].location.y - location_y) <= 0) break;

	if (i == n) return Result;

	Before = Track[i - 1], After = Track[i];
	a = Before.location.y, b = After.location.y;

	Result.location = (Before.location * location_y - Before.location * b + After.location * a - After.location * location_y) / (a - b);
	Result.angle = Before.angle;
	Result.velocity = (Before.velocity * location_y - Before.velocity * b + After.velocity * a - After.velocity * location_y) / (a - b);
	//Result.spin = (Before.spin * location_y - Before.spin * b + After.spin * a - After.spin * location_y) / (a - b);
	Result.spin_angle = (Before.spin_angle * location_y - Before.spin_angle * b + After.spin_angle * a - After.spin_angle * location_y) / (a - b);
	if (Result.spin_angle >= 2 * PI) Result.spin_angle -= 2 * PI; if (Result.spin_angle <= -2 * PI) Result.spin_angle += 2 * PI;
	//Result.spin_euler = (Before.spin_euler * location_y - Before.spin_euler * b + After.spin_euler * a - After.spin_euler * location_y) / (a - b);
	Result.spin_euler = Before.spin_euler;
	Result.spin = Before.spin;

	//Result.location.y = location_y; // ����

	return Result;
}

/*
* frame=10
y = 10 => -10, y=-5
A=100, B=-100 (Y=-50)
a -> b, y (a=10, b=-10, y=-5)

������
(a-y):(y-b)

(a-y):(y-b) = (A-Y):(Y-B)
(y-b)(A-Y) = (a-y)(Y-B)
A(y-b) - Y(y-b) = Y(a-y) - B(a-y)
A(y-b) + B(a-y) = Y(a-y+y-b) = Y(a-b)
Ay-Ab+aB-By = Y(a-b)
*/

dvec3 CBallTrace::CalculateForce(CBallFactor Trace)
{
	dvec3 Force = ForceGrav(Trace) + ForceDrag(Trace) + ForceMagn(Trace)/* + ForceStitch(Trace)*/;

	return Force;
}

dvec3 CBallTrace::ForceGrav(CBallFactor Trace)
{
	dvec3 Force(0, 0, 0);

	Force.z = -Property.g * Property.mass;

	return Force;
}

dvec3 CBallTrace::ForceDrag(CBallFactor Trace)
{
	double v;
	dvec3 Force = Trace.velocity;

	Force *= -0.5 * tmpProperty.C_d * Property.rho * Property.size * Property.size * Property.pi * Trace.velocity_length();

	return Force;
}

dvec3 CBallTrace::ForceMagn(CBallFactor Trace)
{
	// dvec3 spin = EulerAngle(Trace.spin_euler) * Trace.spin / 60.0f * 2.0 * PI;

	dvec3 Force = (EulerAngle(Trace.spin_euler) * Trace.spin).cross(Trace.velocity);
	if (Force.length() == 0) return Force;
	Force = Force.normalize();

	//printf("(%g %g %g)*(%g %g %g) => %g %g %g\n", this->spin.x, this->spin.y, this->spin.z, this->velocity.x, this->velocity.y, this->velocity.z, Force.x, Force.y, Force.z);

	Force *= 0.5 * tmpProperty.C_l * Property.rho * Property.size * Property.size * Property.pi * Trace.velocity_length() * Property.size * Trace.spin;

	// 0.005 ���ϴ� ��ȸ��ó��
	// printf("%.5lf ", Force.length());

	return Force;
}
/*
dvec3 CBallTrace::ForceStitch(CTraceFactor Trace)
{
	float t, x, y, z;
	double Result, Integral = 0;
	dvec3 tv;
	vec4 transpos;
	mat4 rotation_matrix = GetRotationMatrix(Trace.angle);
	dvec3 Force = Trace.velocity.normalize();

	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_longitude);// 0<t<2PI		t=phi
		// x = (1 / 13)(9 cos(a) - 4 cos(3a))	x` = -(1 / 13)(9 sin(a) - 12 sin(3a))
		// y = (1 / 13)(9 sin(a) + 4 sin(3a))	y` = (1 / 13)(9 cos(a) + 12 cos(3a))
		// z = (12 / 13)cos(2a)					z` = -(24 / 13)sin(2a)
		x = (-9.0f * sin(t) + 12.0f * sin(3 * t)) / 13.0f;
		y = (9.0f * cos(t) + 12.0f * cos(3 * t)) / 13.0f;
		z = sin(2 * t) * -24.0f / 13.0f;

		transpos = rotation_matrix * vec4(x, y, z, 1);
		tv = dvec3(transpos.x, transpos.y, transpos.z);

		Integral += Trace.velocity.normalize().dot(tv.normalize()) * (10.93346f / (max_longitude + 1));
	}

	Force *= -Integral * this->f_s;

	return Force;
}*/

