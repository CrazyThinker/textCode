#include "FileList.h"

CFileList::CFileList(void)
{
}

CFileList::CFileList(string folder, string extension)
{
	this->folder = folder;
	this->extension = extension;
}

CFileList::~CFileList(void)
{
}

void CFileList::GetList(void)
{
	int i;
	_finddata_t finddata;
	long handle;
	FILE* fi;

	FileList.clear();
	handle = _findfirst((folder + "*." + extension).c_str(), &finddata);
	if (handle != -1)
	{
		do
		{
			fi = fopen((folder + finddata.name).c_str(), "r");
			if (fi != NULL)
			{
				fclose(fi);
				for (i = strlen(finddata.name) - 1; i >= 0; i--) if (finddata.name[i] == '.') break;
				finddata.name[i] = 0;
				for (i--; i >= 0; i--) if (finddata.name[i] == '\\') break;
				i++;
				FileList.push_back(&finddata.name[i]);
			}
		} while (_findnext(handle, &finddata) != -1);
		_findclose(handle);
	}
}