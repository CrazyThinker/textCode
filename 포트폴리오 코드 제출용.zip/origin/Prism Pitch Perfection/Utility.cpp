#include "Utility.h"
#include <random>

using namespace std;

mat4 GetRotationMatrix(dvec3 Angle)
{
	// ���� ȸ��
	float cx, sx, cy, sy, cz, sz;
	cx = cos(Angle.x); sx = sin(Angle.x);
	cy = cos(Angle.y); sy = sin(Angle.y);
	cz = cos(Angle.z); sz = sin(Angle.z);


	mat4 rotation_matrix_x =
	{
		1,	0,	0,	0,
		0,	cx,-sx,	0,
		0,	sx,	cx,	0,
		0,	0,	0,	1
	};
	mat4 rotation_matrix_y =
	{
		cy,	0,	sy,	0,
		0,	1,	0,	0,
		-sy,0,	cy,	0,
		0,	0,	0,	1
	};
	mat4 rotation_matrix_z =
	{
		cz,-sz,	0,	0,
		sz,	cz,	0,	0,
		0,	0,	1,	0,
		0,	0,	0,	1
	};

	return rotation_matrix_z * rotation_matrix_y * rotation_matrix_x;
}


dvec3 EulerAngle(ivec2 Angle, int min_angle)
{
	double t, ct, st, q, cq, sq;
	t = PI * Angle.x / min_angle; // 0<t<2PI
	q = PI * Angle.y / min_angle;
	ct = cos(t);
	st = sin(t);
	cq = cos(q);
	sq = sin(q);

	return dvec3(sq * ct, sq * st, cq);
}


dvec3 EulerAngle(dvec2 Angle)
{
	double t, ct, st, q, cq, sq;
	t = Angle.x;// 0<t<2PI
	q = Angle.y;
	ct = cos(t);
	st = sin(t);
	cq = cos(q);
	sq = sin(q);

	return dvec3(sq * ct, sq * st, cq);
}

dvec2 aEulerAngle(dvec3 Vector)
{
	Vector = Vector.normalize();
	dvec2 Result;

	Result.x = atan2(Vector.y, Vector.x);
	Result.y = acos(Vector.z);

	if (Result.x >= 2 * PI) Result.x -= 2 * PI; if (Result.x < 0) Result.x += 2 * PI;
	if (Result.y >= 2 * PI) Result.y -= 2 * PI; if (Result.y < 0) Result.y += 2 * PI;

	return Result;
}

ivec2 aEulerAngle(dvec3 Vector, int min_angle)
{
	Vector = Vector.normalize();
	double t, q;

	t = atan2(Vector.y, Vector.x) * (min_angle / PI) + min_angle * 2;
	q = acos(Vector.z) * min_angle / PI;

	return ivec2((int)(t + 0.5f), (int)(q + 0.5f));
}


double GetRandom(double min, double max)
{
	if (min > max) swap(min, max);

	random_device rd;
	mt19937 gen(rd());
	uniform_real_distribution<double> dis(min, max);

	return dis(gen);
}
