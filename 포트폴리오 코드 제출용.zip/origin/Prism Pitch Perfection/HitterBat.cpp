#include "HitterBat.h"
#include "Utility.h"
#include "BallProperty.h"

extern vec3 StrikeZoneSize;
extern CBallProperty tmpProperty;


CHitterBat::CHitterBat(void)
{
	Track.Origin.location = dvec3(0, 0, 0.5f);
	InitBat();
}

CHitterBat::~CHitterBat(void)
{
}


void CHitterBat::InitBat(void)
{
	if (BatType == 1) Track.Origin.spin = tmpProperty.pi * 5.0f, AngleAcc = tmpProperty.pi * 50; // �Ϲ� ��Ʈ
	else Track.Origin.spin = tmpProperty.pi * 4.0f, AngleAcc = tmpProperty.pi * 40; // ū ��Ʈ

	Track.Origin.spin_angle = -tmpProperty.pi * 3 / 2;

	Track.Origin.angle = dvec3(0, 0, tmpProperty.pi / 2);

	idxTrack = 0;
	this->Type = 0;
}


void CHitterBat::ClearBat(void)
{
	idxTrack = 0;
	Type = 0;
	Track.Track.clear();
}


void CHitterBat::SetLocation(dvec2 posCursor, ivec2 StrikeZonePoint_x, ivec2 StrikeZonePoint_y)
{
	double z, a, b, A, B;
	dvec3 location;
	vec2 RectZone_x = vec2(-StrikeZoneSize.z - 0.1f, StrikeZoneSize.z + 0.1f);
	vec2 RectZone_y = vec2(StrikeZoneSize.x - 0.1f, StrikeZoneSize.y + 0.1f);
	// -StrikeZoneSize.z���� StrikeZoneSize.z������ StrikeZonePoint_x.x ~ StrikeZonePoint_x.y�� ��ü��
	// StrikeZoneSize.x���� StrikeZoneSize.y������ StrikeZonePoint_y.x ~ StrikeZonePoint_y.y�� ��ü��

	// angle.x = 0, angle.y = -Origin_angle.y�� �Ǵ� ����
	// location.x + cos(-Origin_angle.y)(Length - SweetSpotZone), location.y + sin(-Origin_angle.y)(Length - SweetSpotZone) ó�����ָ��

	location.x = (posCursor.x - StrikeZonePoint_x.x) / (StrikeZonePoint_x.y - StrikeZonePoint_x.x) * (StrikeZoneSize.z - (-StrikeZoneSize.z)) + (-StrikeZoneSize.z);
	location.y = (2 - StanceMode) * 0.3f;
	location.z = (posCursor.y - StrikeZonePoint_y.x) / (StrikeZonePoint_y.y - StrikeZonePoint_y.x) * (StrikeZoneSize.x - StrikeZoneSize.y) + StrikeZoneSize.y;

	if (RectZone_x.x <= location.x && location.x <= RectZone_x.y && RectZone_y.x <= location.z && location.z <= RectZone_y.y)
	{
		a = (StrikeZoneSize.x * 3 + StrikeZoneSize.y) / 4, b = StrikeZoneSize.y;
		A = (StrikeZoneSize.x * 2 + StrikeZoneSize.y * 3) / 5, B = StrikeZoneSize.y + 0.05f;
		if (location.z >= b) z = B;
		else if (location.z >= a) z = ((b - location.z) * A + (location.z - a) * B) / (b - a);
		else z = A;
		//printf("%.3f ~ %.3f ~ %.3f => %.3f ~ %.3f ~ %.3f\n", a, location.z, b, A, z, B);

		Track.Origin.spin_euler = dvec2(0, asin((z - location.z) / (BatLength - SweetSpotZone)));
		if (!IsRightBatter) Track.Origin.spin_euler.y = -tmpProperty.pi - Track.Origin.spin_euler.y;

		location.x -= cos(Track.Origin.spin_euler.y) * (BatLength - SweetSpotZone);
		location.z += sin(Track.Origin.spin_euler.y) * (BatLength - SweetSpotZone);
		Track.Origin.location = location;
	}
}


void CHitterBat::Swing(double nowframe, double fpsframe)
{
	if (this->Type == 0)
	{
		int i;
		CBallFactor Factor;

		InitBat();
		this->nowframe = nowframe;
		this->frame = fpsframe;

		this->Track.Track.clear();

		this->Track.Property.frame = fpsframe;

		Factor = Track.Origin;
		Track.Track.push_back(Factor);
		for (i = Track.Track.size();; i++)
		{
			Factor.spin_angle += Factor.spin * frame;
			if (Factor.spin_angle < 0)
			{
				Factor.spin += AngleAcc * frame;
			}
			else if (Factor.spin_angle < tmpProperty.pi / 3)
			{
				Factor.spin -= AngleAcc * frame;
			}

			Track.Track.push_back(Factor);
			if (Factor.spin_angle >= tmpProperty.pi / 3) break;
		}

		pre_rotation_matrix_angle = GetRotationMatrix(dvec3(Factor.angle.x, Factor.angle.y, Factor.angle.z));
		pre_BatVector3 = vec4(BatLength, 0, 0, 1);
		pre_BatVector3 = pre_rotation_matrix_angle * pre_BatVector3;

	}
}
/*
double CHitterBat::GetBatThick(double Spot)
{
	switch (BatType)
	{
	case 1:
		if (Spot <= 0 || Spot >= BatLength) return -1;
		else if (0 < Spot && Spot <= BatLength / 3) return BatThick * 0.5;
		else if (BatLength / 3 < Spot && Spot <= BatLength / 3 * 2) return BatThick * 1.5;
		else if (BatLength / 3 * 2 < Spot && Spot < BatLength) return BatThick;

		break;
	}

	return -1;
}
*/
int CHitterBat::IsHit(CBall& Ball)
{
	//if ((Ball.Track[Ball.idxTrack].location - Track.Origin.location).length2() > BatLength * BatLength) return 0; // �ð� ����

	dvec3 BatVector3;
	vec4 BatVector(BatLength, 0, 0, 1);
	mat4 translate_matrix =
	{
		1, 0, 0, (float)Track[idxTrack].location.x,
		0, 1, 0, (float)Track[idxTrack].location.y,
		0, 0, 1, (float)Track[idxTrack].location.z,
		0, 0, 0, 1
	};

	mat4 rotation_matrix = GetRotationMatrix(dvec3(Track[idxTrack].spin_angle, Track[idxTrack].spin_euler.y - tmpProperty.pi / 2, Track[idxTrack].spin_euler.x));

	BatVector = translate_matrix * rotation_matrix * pre_BatVector3;
	BatVector3 = dvec3(BatVector.x, BatVector.y, BatVector.z);

	// ���� ��ǥ�� Ball.location
	// ��Ʈ�� ���� ��ǥ�� this->location
	// ��Ʈ�� �� ��ǥ�� BatVector
	// 
	// ��(��)�� ����(��Ʈ) ������ �Ÿ� ���
	dvec3 v1 = BatVector3 - Track[idxTrack].location;
	dvec3 v2 = Ball.Track[Ball.idxTrack].location - Track[idxTrack].location;

	double vDot = v1.dot(v2) / BatLength;
	dvec3 vCross = v1.cross(v2);

	if (0 <= vDot && vDot <= BatLength)
	{
		double Distance = vCross.length() / BatLength, r = Ball.Track.Property.size + BatThick;
		if (-r <= Distance && Distance <= r)
		{
			//printf("���� %g, ���� %g, %g %g\n", vDot, Distance, BatLength, SweetSpotZone);
			// 3: Hit, 4: Nice Hit
			if (BatLength - SweetSpotZone - 0.1f <= vDot && vDot <= BatLength - SweetSpotZone + 0.1f) return 4;
			else return 3;
		}
	}

	return 0;
}

CBallFactor CHitterBat::Collision(CBall& Ball)
{
	double I_Ball_1 = 1 / (0.4f * Ball.Track.Property.mass * Ball.Track.Property.size * Ball.Track.Property.size), I_Bat_1 = 1 / (BatMass * BatLength * BatLength / 3.0f);
	CBallFactor Origin;

	dvec3 BatVector3;
	vec4 BatVector(BatLength, 0, 0, 1);
	mat4 translate_matrix =
	{
		1, 0, 0, (float)Track[idxTrack].location.x,
		0, 1, 0, (float)Track[idxTrack].location.y,
		0, 0, 1, (float)Track[idxTrack].location.z,
		0, 0, 0, 1
	};

	mat4 rotation_matrix = GetRotationMatrix(dvec3(Track[idxTrack].spin_angle, Track[idxTrack].spin_euler.y - tmpProperty.pi / 2, Track[idxTrack].spin_euler.x));
	mat4 rotation_matrix_angle = GetRotationMatrix(dvec3(Track[idxTrack].angle.x, Track[idxTrack].angle.y, Track[idxTrack].angle.z));

	BatVector = translate_matrix * rotation_matrix * rotation_matrix_angle * BatVector;
	BatVector3 = dvec3(BatVector.x, BatVector.y, BatVector.z);

	dvec3 v1 = Ball.Track[Ball.idxTrack].location - Track[idxTrack].location;
	dvec3 v2 = BatVector3 - Track[idxTrack].location;
	dvec3 v2_cos = v2 * v1.dot(v2) / BatLength / BatLength;
	dvec3 v2_sin = v1 - v2_cos; // ��������
	dvec3 v_Ball = Ball.Track[Ball.idxTrack].velocity - v2_sin.normalize() * v2_cos.length() * Track[idxTrack].spin; // �� �ӵ� - ��Ʈ�� �ӵ� (v = rw)

	dvec3 nv_Ball = v_Ball.normalize();
	dvec3 nv_Bat = v2_sin.normalize();

	Origin.location = Ball.Track[Ball.idxTrack].location;
	Origin.velocity = (nv_Ball - nv_Bat * (nv_Ball.dot(nv_Bat) * 2)).normalize();
	double sweetzonebonus = 1.0f;
	if (BatLength - SweetSpotZone - 0.1f <= v2_cos.length() && v2_cos.length() <= BatLength - SweetSpotZone + 0.1f) sweetzonebonus = 2.0f;
	Origin.velocity *= v_Ball.length() * tmpProperty.e_v * sweetzonebonus;

	Origin.spin = 0;
	Origin.spin_angle = 0;
	Origin.spin_euler = dvec2(0, 0);
	Origin.angle = dvec3(0, 0, 0);

	return Origin;
}
