#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility

mat4 GetRotationMatrix(dvec3 Angle);
dvec3 EulerAngle(ivec2 Angle, int min_angle);
dvec3 EulerAngle(dvec2 Angle);
dvec2 aEulerAngle(dvec3 Vector);
ivec2 aEulerAngle(dvec3 Vector, int min_angle);
double GetRandom(double min, double max);
