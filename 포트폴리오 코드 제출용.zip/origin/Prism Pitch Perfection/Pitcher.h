#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility

#include "Ball.h"

using namespace std;

class CPitcher
{
public:
	CPitcher(void);
	~CPitcher(void);

public:
	double Strength;
	int TotalFrequency;
	int PitchCount;
	vector<CBallTrace> PitchBall;

public:
	bool LoadPitcher(const char* szFileName, CBallProperty Property);
	bool SavePitcher(const char* szFileName);
	int RandomBallType(void); // ���� ������
	CBallTrace UpdateCondition(CBallTrace& Ball); // ü��(�����)
	dvec2 RandomCourse(tuple<ivec2, ivec2, ivec2> iVelocity, int Cursor); // �ڽ� ������
	CBallTrace RandomBall(CBallTrace Ball, dvec2 CustomiVelocity, double Accuracy);

	void Expenditure(void); // ü�� �Ҹ�

};
