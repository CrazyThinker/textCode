#pragma once
#include "GeometryBuffer.h"
#include "Ball.h"

class CHitterBat
{
public:
	CHitterBat(void);
	~CHitterBat(void);

public:
	int BatType;
	int StanceMode = 2; // 1: Close, 2: Standard, 3: Deep
	int idxTrack;
	CBallTrace Track;

	float BatLength, BatThick, SweetSpotZone, BatMass = 0.893f;
	double frame;
	double nowframe;
	int Type; // 0: Stop, 1: Moving, 2: CoolTime
	bool IsRightBatter = true; // ��Ÿ/��Ÿ
	double AngleAcc;

private:
	mat4 pre_rotation_matrix_angle;
	vec4 pre_BatVector3; // with rotation_matrix_angle

public:
	void InitBat(void);
	void ClearBat(void);
	void SetLocation(dvec2 posCursor, ivec2 StrikeZonePoint_x, ivec2 StrikeZonePoint_y);
	void Swing(double nowframe, double fpsframe);
	//double GetBatThick(double Spot);
	int IsHit(CBall& Ball); // 0: Not hit, 3: Hit, 4: Nice Hit
	CBallFactor Collision(CBall& Ball); // �浹 ������ ���� ���

};
