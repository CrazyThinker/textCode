#include "BatInfo.h"


extern uint max_longitude;
extern uint max_latitude;


CBatInfo::CBatInfo(void)
{
}


CBatInfo::~CBatInfo(void)
{
}


void CBatInfo::CreateBat1(GLuint program, float Thick, float Length, float SweetSpotZone)
{
	this->Thick = Thick;
	this->Length = Length;
	this->SweetSpotZone = SweetSpotZone;

	std::vector<vertex> v;
	std::vector<uint> indices;

	vec3 Color;
	int size, i;
	float t, ct, st, q, cq, sq;
	float x, y, z;
	vec3 pos1, pos2;


	// BatType 1
	Color = vec3(231 / 255.0f, 203 / 255.0f, 163 / 255.0f);
	v.clear();
	indices.clear();

	////////// ��Ʈ��
	size = v.size();
	v.push_back({ vec3(Length, 0, 0), Color * 0.8f, vec2(0.0f,3.0f) });
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_latitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		pos1 = vec3(Length, ct * Thick, st * Thick);
		v.push_back({ pos1, Color * 0.8f, vec2(0.0f,3.0f) });
	}
	// create buffers
	for (uint k = 0; k < max_longitude - 1; k++)//origin to sphere
	{
		// think that k*max_longitude+i is already done
		//first triangle of square
		indices.push_back(size);
		indices.push_back(size + k + 1);
		indices.push_back(size + k + 2);
		indices.push_back(size);
		indices.push_back(size + k + 2);
		indices.push_back(size + k + 1);
		//second triangle of squre
	}


	////////// ��Ʈ��
	size = v.size();
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_latitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		pos1 = vec3(Length / 3 * 2, ct * Thick, st * Thick);
		pos2 = vec3(Length, ct * Thick, st * Thick);
		v.push_back({ pos1, Color * 0.95f, vec2(0.0f,3.0f) });
		v.push_back({ pos2, Color * 0.95f, vec2(0.0f,3.0f) });
	}
	// create buffers
	for (uint k = 0; k < max_longitude; k += 2)//origin to sphere
	{
		// think that k*max_longitude+i is already done
		//first triangle of square
		indices.push_back(size + k);
		indices.push_back(size + k + 1);
		indices.push_back(size + k + 3);
		indices.push_back(size + k);
		indices.push_back(size + k + 2);
		indices.push_back(size + k + 3);
		indices.push_back(size + k);
		indices.push_back(size + k + 3);
		indices.push_back(size + k + 1);
		indices.push_back(size + k);
		indices.push_back(size + k + 3);
		indices.push_back(size + k + 2);
		//second triangle of squre
	}


	////////// ��Ʈ ������ ����
	size = v.size();
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_latitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		pos1 = vec3(Length / 3, ct * Thick / 2, st * Thick / 2);
		pos2 = vec3(Length / 3 * 2, ct * Thick, st * Thick);
		v.push_back({ pos1, Color * 0.975f, vec2(0.0f,3.0f) });
		v.push_back({ pos2, Color * 0.975f, vec2(0.0f,3.0f) });
	}
	// create buffers
	for (uint k = 0; k < max_longitude; k += 2)//origin to sphere
	{
		// think that k*max_longitude+i is already done
		//first triangle of square
		indices.push_back(size + k);
		indices.push_back(size + k + 1);
		indices.push_back(size + k + 3);
		indices.push_back(size + k);
		indices.push_back(size + k + 2);
		indices.push_back(size + k + 3);
		indices.push_back(size + k);
		indices.push_back(size + k + 3);
		indices.push_back(size + k + 1);
		indices.push_back(size + k);
		indices.push_back(size + k + 3);
		indices.push_back(size + k + 2);
		//second triangle of squre
	}


	////////// ������
	size = v.size();
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_latitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		pos1 = vec3(0, ct * Thick / 2, st * Thick / 2);
		pos2 = vec3(Length / 3, ct * Thick / 2, st * Thick / 2);
		v.push_back({ pos1, Color, vec2(0.0f,3.0f) });
		v.push_back({ pos2, Color, vec2(0.0f,3.0f) });
	}
	// create buffers
	for (uint k = 0; k < max_longitude; k += 2)//origin to sphere
	{
		// think that k*max_longitude+i is already done
		//first triangle of square
		indices.push_back(size + k);
		indices.push_back(size + k + 1);
		indices.push_back(size + k + 3);
		indices.push_back(size + k);
		indices.push_back(size + k + 2);
		indices.push_back(size + k + 3);
		indices.push_back(size + k);
		indices.push_back(size + k + 3);
		indices.push_back(size + k + 1);
		indices.push_back(size + k);
		indices.push_back(size + k + 3);
		indices.push_back(size + k + 2);
		//second triangle of squre
	}

	vertex_Preview.InitBuffer(v, indices, GL_TRIANGLES, program);


	////////// ��Ʈ�Ӹ�
	size = v.size();
	for (uint k = 0; k <= max_longitude; k++)
	{
		t = PI * 2.0f * k / float(max_longitude);// 0<t<2PI		t=phi
		ct = cos(t);
		st = sin(t);
		for (uint i = 0; i <= max_latitude; i++)
		{
			q = PI * int(i) / float(max_latitude);// 0<q<PI		q=theta
			cq = cos(q);
			sq = sin(q);
			pos1 = vec3(sq * ct * Thick * 0.9f, sq * st * Thick, cq * Thick * 0.9f);
			v.push_back({ pos1, Color * 0.9f, vec2(0.0f,3.0f) });
		}
	}
	// create buffers
	for (uint k = 0; k < max_longitude; k++)//origin to sphere
	{
		for (uint i = 0; i < max_latitude; i++)
		{
			// think that k*max_longitude+i is already done
			//first triangle of square
			indices.push_back(size + k * (max_latitude + 1) + i);
			indices.push_back(size + k * (max_latitude + 1) + i + 1);
			indices.push_back(size + (k + 1) * (max_latitude + 1) + i);
			//second triangle of squre
			indices.push_back(size + (k + 1) * (max_latitude + 1) + i);
			indices.push_back(size + k * (max_latitude + 1) + i + 1);
			indices.push_back(size + (k + 1) * (max_latitude + 1) + i + 1);
		}
	}

	vertex_Bat.InitBuffer(v, indices, GL_TRIANGLES, program);
}
