#include "AsyncClient.h"
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility
#include "trackball.h"	// virtual trackball

#include "stb_truetype.h"
#include <irrKlang/x32/irrKlang.h>

#include "Ball.h"
#include "BallTrace.h"
#include "GeometryBuffer.h"
#include "HitterBat.h"
#include "Pitcher.h"
#include "FileList.h"
#include "ModeMain.h"

#pragma comment(lib,"irrKlang.lib")

//*************************************
bool init_text();

// global constants
static const char* window_name = "Prism Pitch Perfection";
static const char* vert_shader_path = "../bin/shaders/trackball.vert";
static const char* frag_shader_path = "../bin/shaders/trackball.frag";

// CMode
CModeMain ModeProgram;


//*************************************
// window objects
GLFWwindow* window = nullptr;
ivec2		window_size = cg_default_window_size(); // initial window size

//*************************************
// OpenGL objects
GLuint	program = 0;						// ID holder for GPU program
extern GLuint	program_text;				// ID holder for GPU text program


//*************************************
// global variables
int		frame = 0;				// index of rendering frames

// Basic Settings
int		framefps = 1000;				// ���Ϸ� �Է�
int		ball_framefps = 10000;			// 
int		root_division = 50;				// �� ��Ʈ�� �������� ǥ���� ������ ����
uint	max_longitude = 72;				// max longitude
uint	max_latitude = 36;				// max latitude
uint	min_spin_angle = 80;
uint	min_velocity_angle = 1800;
int		boundary_spin = 10000;			// �ִ� rpm
double	SlowMode = 0.2f;

vec3 StrikeZoneSize(0.35f, 0.90f, 0.215f);
vector < pair<ivec2, pair<ivec2, ivec2> > > StrikeZonePoint;

CBallProperty tmpProperty;						// Basic Settings

bool	is_pause = false;						// is pause?


irrklang::ISoundEngine* engine = nullptr;
irrklang::ISoundSource* sound_collision = nullptr;
irrklang::ISoundSource* sound_error = nullptr;
irrklang::ISoundSource* sound_gamestart = nullptr;
irrklang::ISoundSource* sound_select = nullptr;

//*************************************
// scene objects
mesh* pMesh = nullptr;
trackball	tb;


void save_settings(void)
{
	int i, len;
	FILE* fo = fopen("settings.txt", "w");

	fprintf(fo, "framefps %d\n", framefps);
	fprintf(fo, "boundary_spin %d\n", boundary_spin);
	fprintf(fo, "strikezone_size %g %g %g\n", StrikeZoneSize.x, StrikeZoneSize.y, StrikeZoneSize.z);

	len = StrikeZonePoint.size();
	for (i = 0; i < len; i++)
	{
		fprintf(fo, "strikezone_point %d %d %d %d %d %d\n", StrikeZonePoint[i].first.x, StrikeZonePoint[i].first.y, StrikeZonePoint[i].second.first.x, StrikeZonePoint[i].second.first.y, StrikeZonePoint[i].second.second.x, StrikeZonePoint[i].second.second.y);
	}

	fprintf(fo, "\n");
	fprintf(fo, "g %g\n", tmpProperty.g);
	fprintf(fo, "C_d %g\n", tmpProperty.C_d);
	fprintf(fo, "C_l %g\n", tmpProperty.C_l);
	fprintf(fo, "e_v %g\n", tmpProperty.e_v);
	fprintf(fo, "e_g %g\n", tmpProperty.e_g);
	fprintf(fo, "slowmode %g\n", SlowMode);

	fclose(fo);
}


void init_settings(void)
{
	int i, len, Data, Data1, Data2, Data3, Data4, Data5, Data6;
	char szText[1024];
	float fData1, fData2, fData3;

	FILE* fi = fopen("settings.txt", "r");
	if (fi != NULL)
	{
		StrikeZonePoint.clear();
		while(fscanf(fi, "%s", szText) != EOF)
		{
			if (strcmp(szText, "framefps") == 0)
			{
				fscanf(fi, "%d", &Data);
				framefps = Data;
			}
			else if (strcmp(szText, "boundary_spin") == 0)
			{
				fscanf(fi, "%d", &Data);
				boundary_spin = Data;
			}
			else if (strcmp(szText, "strikezone_size") == 0)
			{
				fscanf(fi, "%f%f%f", &fData1, &fData2, &fData3);
				StrikeZoneSize = vec3(fData1, fData2, fData3);
			}
			else if (strcmp(szText, "strikezone_point") == 0)
			{
				fscanf(fi, "%d%d%d%d%d%d", &Data1, &Data2, &Data3, &Data4, &Data5, &Data6);
				StrikeZonePoint.push_back(make_pair(ivec2(Data1, Data2), make_pair(ivec2(Data3, Data4), ivec2(Data5, Data6))));
			}
			else if (strcmp(szText, "g") == 0)
			{
				fscanf(fi, "%f", &fData1);
				tmpProperty.g = fData1;
			}
			else if (strcmp(szText, "C_d") == 0)
			{
				fscanf(fi, "%f", &fData1);
				tmpProperty.C_d = fData1;
			}
			else if (strcmp(szText, "C_l") == 0)
			{
				fscanf(fi, "%f", &fData1);
				tmpProperty.C_l = fData1;
			}
			else if (strcmp(szText, "e_v") == 0)
			{
				fscanf(fi, "%f", &fData1);
				tmpProperty.e_v = fData1;
			}
			else if (strcmp(szText, "e_g") == 0)
			{
				fscanf(fi, "%f", &fData1);
				tmpProperty.e_g = fData1;
			}
			else if (strcmp(szText, "slowmode") == 0)
			{
				fscanf(fi, "%f", &fData1);
				SlowMode = fData1;
			}
		}
		fclose(fi);
	}

	save_settings();

	ModeProgram.framefps = framefps;
	ModeProgram.ball_framefps = ball_framefps;
	ModeProgram.root_division = root_division;
	ModeProgram.max_longitude = max_longitude;
	ModeProgram.max_latitude = max_latitude;
	ModeProgram.min_spin_angle = min_spin_angle;
	ModeProgram.min_velocity_angle = min_velocity_angle;
	ModeProgram.boundary_spin = boundary_spin;
	ModeProgram.StrikeZoneSize = StrikeZoneSize;
	if (StrikeZonePoint.size() > 0)
	{
		ModeProgram.StrikeZonePoint_x = StrikeZonePoint[0].second.first;
		ModeProgram.StrikeZonePoint_y = StrikeZonePoint[0].second.second;

		len = StrikeZonePoint.size();
		for (i = 1; i < len; i++)
		{
			if (StrikeZonePoint[i].first == window_size)
			{
				ModeProgram.StrikeZonePoint_x = StrikeZonePoint[i].second.first;
				ModeProgram.StrikeZonePoint_y = StrikeZonePoint[i].second.second;
				break;
			}
		}
	}
}


void update_camera()
{
	// update projection matrix
	ModeProgram.cam.aspect = window_size.x / float(window_size.y);
	ModeProgram.cam.projection_matrix = mat4::perspective(ModeProgram.cam.fovy, ModeProgram.cam.aspect, ModeProgram.cam.dnear, ModeProgram.cam.dfar);




	// update uniform variables in vertex/fragment shaders
	GLint uloc;
	uloc = glGetUniformLocation(program, "view_matrix");			if (uloc > -1) glUniformMatrix4fv(uloc, 1, GL_TRUE, ModeProgram.cam.view_matrix);
	uloc = glGetUniformLocation(program, "projection_matrix");	if (uloc > -1) glUniformMatrix4fv(uloc, 1, GL_TRUE, ModeProgram.cam.projection_matrix);
}


void reshape(GLFWwindow* window, int width, int height)
{
	// set current viewport in pixels (win_x, win_y, win_width, win_height)
	// viewport: the window area that are affected by rendering 
	if (window_size != ivec2(width, height))
	{
		int i;

		window_size = ivec2(width, height);
		ModeProgram.window_size = window_size;
		for (i = StrikeZonePoint.size() - 1; i >= 0; i--)
		{
			if (StrikeZonePoint[i].first == window_size)
			{
				ModeProgram.StrikeZonePoint_x = StrikeZonePoint[i].second.first;
				ModeProgram.StrikeZonePoint_y = StrikeZonePoint[i].second.second;
				break;
			}
		}
	}
	glViewport(0, 0, width, height);
}

//<<<<<<<<<<<<<<<<
void print_help()
{
	printf("[help]\n");
	printf("- press ESC or 'q' to terminate the program.\n");
	printf("- Customize the pitch of the ball.\n");
	printf("- It is able to customize two balls.\n");
	printf("- Compare the two different balls in a various aspects.\n");

//#ifndef GL_ES_VERSION_2_0
//	printf("- press 'w' to toggle wireframe\n");
//#endif
//	printf("\n");
}


void pause_handling()
{
	GLint uloc;

	glUseProgram(program);

	if (is_pause)
	{
		uloc = glGetUniformLocation(program, "b_pause");	if (uloc > -1) glUniform1i(uloc, 1);
	}
	else
	{
		uloc = glGetUniformLocation(program, "b_pause");	if (uloc > -1) glUniform1i(uloc, 0);
	}
}


// keyboard
void keyboard(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	ModeProgram.Keyboard(window, key, scancode, action, mods);
}

void mouse(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT || GLFW_MOUSE_BUTTON_MIDDLE || GLFW_MOUSE_BUTTON_RIGHT)
	{
		if (ModeProgram.move_camera_direction)
		{
			dvec2 pos; glfwGetCursorPos(window, &pos.x, &pos.y);
			vec2 npos = cursor_to_ndc(pos, window_size);
			if (action == GLFW_PRESS)			tb.begin(ModeProgram.cam.view_matrix, npos, ModeProgram.cam.eye, ModeProgram.cam.at, ModeProgram.cam.up);
			else if (action == GLFW_RELEASE)	tb.end();
		}
	}
	tb.button = button;
	tb.mods = mods;

	ModeProgram.Mouse(window, button, action, mods);
}

void motion(GLFWwindow* window, double x, double y)
{
/*	if (!tb.is_tracking()) return;
	vec2 npos = cursor_to_ndc(dvec2(x, y), window_size);
	if (tb.button == GLFW_MOUSE_BUTTON_LEFT && tb.mods == 0)
		currentcam->view_matrix = tb.update(npos, currentcam->eye, currentcam->at, currentcam->up);
	else if (tb.button == GLFW_MOUSE_BUTTON_MIDDLE || (tb.button == GLFW_MOUSE_BUTTON_LEFT && (tb.mods & GLFW_MOD_CONTROL)))
		currentcam->view_matrix = tb.update_pan(npos, currentcam->eye, currentcam->at, currentcam->up);
	else if (tb.button == GLFW_MOUSE_BUTTON_RIGHT || (tb.button == GLFW_MOUSE_BUTTON_LEFT && (tb.mods & GLFW_MOD_SHIFT)))
		currentcam->view_matrix = tb.update_zoom(npos, currentcam->eye, currentcam->at, currentcam->up);*/
	if (!tb.is_tracking()) return;
	else if (!ModeProgram.move_camera_direction) return;
	vec2 npos = cursor_to_ndc(dvec2(x, y), window_size);
	if (tb.button == GLFW_MOUSE_BUTTON_LEFT && tb.mods == 0)
		ModeProgram.cam.view_matrix = tb.update(npos, ModeProgram.cam.eye, ModeProgram.cam.at, ModeProgram.cam.up);
	else if (tb.button == GLFW_MOUSE_BUTTON_MIDDLE || (tb.button == GLFW_MOUSE_BUTTON_LEFT && (tb.mods & GLFW_MOD_CONTROL)))
		ModeProgram.cam.view_matrix = tb.update_pan(npos, ModeProgram.cam.eye, ModeProgram.cam.at, ModeProgram.cam.up);
	else if (tb.button == GLFW_MOUSE_BUTTON_RIGHT || (tb.button == GLFW_MOUSE_BUTTON_LEFT && (tb.mods & GLFW_MOD_SHIFT)))
		ModeProgram.cam.view_matrix = tb.update_zoom(npos, ModeProgram.cam.eye, ModeProgram.cam.at, ModeProgram.cam.up);

	// cam.view_matrix = tb.update( npos );
}

// initialize
bool user_init()
{
	GLint uloc;

	uloc = glGetUniformLocation(program, "b_pause");	if (uloc > -1) glUniform1i(uloc, 0);
	uloc = glGetUniformLocation(program, "b_modered");	if (uloc > -1) glUniform1i(uloc, 0);
	uloc = glGetUniformLocation(program, "b_modegreen");	if (uloc > -1) glUniform1i(uloc, 0);
	uloc = glGetUniformLocation(program, "b_modeblue");	if (uloc > -1) glUniform1i(uloc, 0);

	//initializing image
	glClearColor(39 / 255.0f, 40 / 255.0f, 34 / 255.0f, 1.0f);	// set clear color
	glEnable(GL_CULL_FACE);			// turn on backface culling
	glEnable(GL_DEPTH_TEST);			// turn on depth tests
	glActiveTexture(GL_TEXTURE0);		// notify GL the current texture slot is 0

	// create corners and vertices
	vertex corners[4];
	corners[0].pos = vec3(-1.0f, -1.0f, 0.0f);	corners[0].tex = vec2(0.0f, 0.0f);
	corners[1].pos = vec3(+1.0f, -1.0f, 0.0f);	corners[1].tex = vec2(1.0f, 0.0f);
	corners[2].pos = vec3(+1.0f, +1.0f, 0.0f);	corners[2].tex = vec2(1.0f, 1.0f);
	corners[3].pos = vec3(-1.0f, +1.0f, 0.0f);	corners[3].tex = vec2(0.0f, 1.0f);
	vertex verticesimg[6] = { corners[0], corners[1], corners[2], corners[0], corners[2], corners[3] };

	// generation of vertex buffer is the same, but use vertices instead of corners
	GLuint vertex_buffer;
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(verticesimg), verticesimg, GL_STATIC_DRAW);

	// generate vertex array object, which is mandatory for OpenGL 3.3 and higher
	/*if (vertex_array_sphere) glDeleteVertexArrays(1, &vertex_array_sphere);
	vertex_array_sphere = cg_create_vertex_array(vertex_buffer);
	if (!vertex_array_sphere) { printf("%s(): failed to create vertex aray\n", __func__); return false; }*/


	// initializing font
	glClearColor(39 / 255.0f, 40 / 255.0f, 34 / 255.0f, 1.0f);	// set clear color
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// create a vertex array for triangles in default view volume: [-1~1, -1~1, -1~1]
	vertex verticesfont[] =
	{
		{ vec3(0.433f,-0.25f,0), vec3(1,0,0), vec2(0.0f) },  // {position, red color, ...}
		{ vec3(0.0f,0.5f,0), vec3(0,1,0), vec2(0.0f) },      // {position, green color, ...}
		{ vec3(-0.433f,-0.25f,0), vec3(0,0,1), vec2(0.0f) }  // {position, blue color, ...}
	};

	// create and update vertex buffer
	vertex_buffer = 0;
	glGenBuffers(1, &vertex_buffer); // generate a buffer object
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer); // notify GL to use the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verticesfont), verticesfont, GL_STATIC_DRAW); // copy data to GPU

	// setup freetype
	if (!init_text()) return false;

	//initializing sound
	engine = irrklang::createIrrKlangDevice();
	if (!engine) return false;
	//add sound source from the sound file
	sound_collision = engine->addSoundSourceFromFile("../bin/sound/Collision.mp3");
	sound_error = engine->addSoundSourceFromFile("../bin/sound/Error.mp3");
	sound_gamestart = engine->addSoundSourceFromFile("../bin/sound/GameStart.mp3");
	sound_select = engine->addSoundSourceFromFile("../bin/sound/Select.mp3");

	// log hotkeys
	print_help();

	// define the position of four corner vertices
	init_settings();

	// create vertex buffer; called again when index buffering mode is toggled

	return true;
}

void user_finalize()
{
	//close the engine
	engine->drop();
}

int main(int argc, char* argv[])
{
	srand((unsigned int)time(NULL));
	StrikeZonePoint.clear();
	StrikeZonePoint.push_back(make_pair(ivec2(720, 480), make_pair(ivec2(304, 416), ivec2(200, 346))));

	// create window and initialize OpenGL extensions
	if (!(window = cg_create_window(window_name, window_size.x, window_size.y))) { glfwTerminate(); return 1; }
	if (!cg_init_extensions(window)) { glfwTerminate(); return 1; }	// version and extensions

	// initializations and validations
	if (!(program = cg_create_program(vert_shader_path, frag_shader_path))) { glfwTerminate(); return 1; }	// create and compile shaders/program
	if (!user_init()) { printf("Failed to user_init()\n"); glfwTerminate(); return 1; }					// user initialization

	// register event callbacks
	glfwSetWindowSizeCallback(window, reshape);	// callback for window resizing events
	glfwSetKeyCallback(window, keyboard);			// callback for keyboard events
	glfwSetMouseButtonCallback(window, mouse);	// callback for mouse click inputs
	glfwSetCursorPosCallback(window, motion);		// callback for mouse movement
	glViewport(0, 0, window_size.x, window_size.y);

	ModeProgram.Program = program;
	ModeProgram.Window = window;
	ModeProgram.framefps = framefps;
	ModeProgram.window_size = window_size;

	ModeProgram.Initialize_Main();

	// enters rendering/event loop
	for (frame = 0; !glfwWindowShouldClose(window); frame++)
	{
		glfwPollEvents();	// polling and processing of events
		update_camera();	// per-frame update camera

		ModeProgram.t = glfwGetTime();
		ModeProgram.Initialize();
		ModeProgram.Render();
		ModeProgram.Update();
		ModeProgram.Exception();
	}

	// normal termination
	user_finalize();
	cg_destroy_window(window);

	return 0;
}
