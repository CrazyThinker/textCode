#pragma once
#include "cgmath.h"		// slee's simple math library
#include "cgut.h"		// slee's OpenGL utility
#include <list>

#include "Ball.h"
#include "Pitcher.h"
#include "GeometryBuffer.h"
#include "HitterBat.h"
#include "BatInfo.h"


struct CCamera
{
	// ���� ����
	vec3	eye;
	vec3	at;
	vec3	up;
	mat4	view_matrix;

	float	fovy = PI / 4.0f; // must be in radian
	float	aspect;
	float	dnear = 1.0f;
	float	dfar = 1000.0f;
	mat4	projection_matrix;
};


class CModeComponent
{
public:
	CModeComponent(void);
	~CModeComponent(void);

public:
	int ProgramMode;
	GLuint Program;						// ID holder for GPU program
	GLFWwindow* Window = nullptr;
	bool move_camera_direction;
	double t;
	CCamera cam;
	int nowcam;
	vector<CCamera> camlist;
	int mode_track;
	list<pair<double, int> > Schedule;

	ivec2	window_size;
	ivec2	StrikeZonePoint_x;
	ivec2	StrikeZonePoint_y;

	int nStanceMode = 3;
	const char* StanceMode[3 + 1] = { "", "Close Stance", "Standard Stance", "Deep Stance" };
	double BatterPitchMinigameAccuracy[4] = { 0.70f, 0.80f, 0.90f, 1.00f };
	double PitcherPitchMinigameAccuracy[4] = { 0.80f, 0.90f, 0.95f, 1.00f };
	double PitchMinigameWeight[4 + 1] = { 0 };
	double PitcherCursorVelocity;

public:
	double	nowframe;
	int		framefps;					// ���Ϸ� �Է�
	int		ball_framefps;				// ���Ϸ� �Է�
	int		root_division;				// �� ��Ʈ�� �������� ǥ���� ������ ����
	uint	max_longitude;				// max longitude
	uint	max_latitude;				// max latitude
	uint	min_spin_angle;
	uint	min_velocity_angle;
	int		boundary_spin;
	double	max_previewspin = 200;		// rpm
	ivec2	boundary_velocity = ivec2(50, 170);
	vec3	StrikeZoneSize;

public:
	CGeometryBuffer	vertex_BaseBall;
	CGeometryBuffer	vertex_Ground;
	CGeometryBuffer vertex_InfieldGround;
	CGeometryBuffer	vertex_GrassLine;
	CGeometryBuffer	vertex_3FeetLine;
	CGeometryBuffer	vertex_StrikeZone;
	CGeometryBuffer	vertex_LBatterZone;
	CGeometryBuffer	vertex_RBatterZone;
	CGeometryBuffer	vertex_BaseLine;
	CGeometryBuffer	vertex_HomePlate;
	CGeometryBuffer	vertex_1BasePlate;
	CGeometryBuffer	vertex_2BasePlate;
	CGeometryBuffer	vertex_3BasePlate;
	CGeometryBuffer	vertex_Circle;
	CGeometryBuffer	vertex_Donut;
	CGeometryBuffer	vertex_BallMovement;
	CGeometryBuffer vertex_PitcherCursor;
	CGeometryBuffer vertex_PitcherBar;

	// Bat
	vector<CBatInfo> BatInfo;

public:
	virtual void Initialize(void) {}
	virtual void Update(void);
	virtual void Render(void) {}
	virtual void Keyboard(GLFWwindow* window, int key, int scancode, int action, int mods) {}
	virtual void Mouse(GLFWwindow* window, int button, int action, int mods) {}

	void SetWindowSize(ivec2 window_size);
	mat4 GetMatrixTranslate(int x, int y, int width, int height);

private:
	ivec2 CalculateiVelocity(CBall& Ball, vec3 corLocation, ivec2 iVelocity, uint min_velocity_angle, int ball_framefps);

public:
	tuple<ivec2, ivec2, ivec2> CalculateDirection(CBall& Ball, vec3 StrikeZoneSize, uint min_velocity_angle, int ball_framefps);

	pair<vector<vertex>, vector<uint> > Initialize_BaseBall_vertex(float thick); // BaseBall
	void Initialize_Vertex(void); // Program�� ���� �־���մϴ�
	void Initialize_Bat(void); // Program�� ���� �־���մϴ�
	void Initialize_Camera(int Type);

	void Camera_Prev(void);
	void Camera_Next(void);
	void Camera_Home(void);

	void ClearSchedule(void);
	void SetSchedule(CBallTrace& Track, int n, double nowframe, int Type, double SlowMode);
	void SetSchedule(CBall& BaseBall, int Type, double SlowMode);
	void SetSchedule(CHitterBat& Bat);
	void SetSchedule(double frame, int Type);
	int GetSchedule(double nowframe = 0);
	void RemoveSchedule(int Type);
	bool EmptySchedule(void);

	void Render_Text(string text, GLint x, GLint y, GLfloat scale, vec4 color, GLfloat dpi_scale = 1.0f);		// text ���
	void Render_BaseBall(CBall& BaseBall, bool OnlySpin = false);												// BaseBall�� ���
	void Render_BallZone(CBall& BaseBall, int mode);															// ��Ʈ����ũ���� ǥ�õ� �� ���, 0: Ball, 1: Strike, 2: BaseBall, 3: ������
	void Render_BattingGuide(CBall& BaseBall);																	// ���� ���̵� ���
	void Render_Bat(CHitterBat& Bat, bool Preview = false);														// Bat ���
	void Render_Stadium(bool b_StrikeZone = true);																// ����� ���
	void Render_Line(dvec3 From, dvec3 To);																		// �� ���
	void Render_SpinAxis(CBall& BaseBall, dvec3 axis);															// ���� ȸ���� ���
	void Render_SpinAxis(CBall& BaseBall, ivec2 axis);															// ���� ȸ���� ���
	void Render_BallMovement(CBall& BaseBall);																	// ���� �̵���� ���
	void Render_PitchSign(double PitchSignType);																// ��Ī�ӽ� ���
	void Render_PitcherStrength(double Strength);																// ���� ü�¹� ���
	void Render_StanceMode(int Cursor);																			// Ÿ�� ���Ľ���� ���
	void Render_PitchMinigame(int BoardCursor);
	void Render_PitchboardProficiency(double proficiency, int x, int y);
	void Render_Pitchboard(CPitcher& Pitcher, int Cursor); // Use BallCursor

	void Update_Ball(CBall& BaseBall);
	void Update_Bat(CHitterBat& Bat);
	void Update_BatLocation(CHitterBat& Bat);

	void CheckBatHit(CBall& BaseBall, CHitterBat& Bat, double Power);
	double GetPitcherMinigameAccuracy(double BoardCursor);
	double RandomAccuracy(int Type); // ���� ��Ȯ��
	void Set_PitcherMinigame(double Strength);

};
